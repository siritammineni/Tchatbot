import os
import json
import re
import pandas as pd
from dotenv import load_dotenv
from langchain_core.tools import tool
from langchain_openai import AzureChatOpenAI
from langchain.agents import initialize_agent, AgentType

load_dotenv()

class CSVSchemaProcessor:
    @staticmethod
    @tool
    def generate_schema(csv_path: str) -> str:
        """
        Tool to generate a schema from a CSV file.
        Accepts:
            - csv_path: Path to CSV file
        """
        df = pd.read_csv(csv_path).head(7)
        rows = [f"{col}: {dtype}" for col, dtype in zip(df.columns, df.dtypes)]
        return "\n".join(rows)

    @staticmethod
    def clean_json_output(llm_output: str) -> str:
        """Remove markdown and extract clean JSON list from the string."""
        cleaned = re.sub(r"```(?:json)?", "", llm_output, flags=re.IGNORECASE).strip()
        match = re.search(r'(\[\s*{.*?}\s*\])', cleaned, re.DOTALL)
        if match:
            return match.group(1)
        return cleaned

    def __init__(self, 
                 folder_path: str, 
                 output_dir: str = "./Files"):
        self.folder_path = folder_path
        self.output_dir = output_dir
        self.llm = AzureChatOpenAI(
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT_DOC_COMP"),
            deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
            temperature=0.3,
        )
        self.schema_columns = "column_name, column_type, sample_value, is_primary_key, is_foreign_key"
        self.JSON_Format = '''
        [
            {
                column_name:<column name>,
                column_type:<column type>,
                sample_value:<sample value>,
                is_primary_key:<True/False>,
                is_foreign_key:<True/False>
            }
            // ...
        ]'''
        self.tools = [self.generate_schema]
        self.agent = initialize_agent(
            tools=self.tools,
            llm=self.llm,
            agent=AgentType.OPENAI_FUNCTIONS,
            verbose=True,
        )

    def process(self):
        os.makedirs(self.output_dir, exist_ok=True)
        all_schema_data = []

        for filename in os.listdir(self.folder_path):
            if filename.endswith(".csv"):
                csv_path = os.path.join(self.folder_path, filename)
                prompt = f"""Generate a schema for this CSV file: {csv_path}. I want these {self.schema_columns} to be included in \
the schema. Give me the output in JSON_Format only. Generate a valid JSON array with the following structure: [ ... ]\
Do not include any text before or after the JSON array.\
Use this {self.JSON_Format} as output reference. DO not add any extra words into the json format, only give proper \
response. Do not give any extra data."""

                print(f"\n📄 Processing: {filename}")
                result = self.agent.run(prompt)

                try:
                    clean_result = self.clean_json_output(result)
                    schema_data = json.loads(clean_result)
                    all_schema_data.append({
                        "table_name": os.path.splitext(filename)[0],
                        "columns": schema_data
                    })
                except Exception as e:
                    print(f"❌ Failed to parse schema for {filename}: {e}")

        combined_path = os.path.join(self.output_dir, "schema.json")
        with open(combined_path, "w", encoding="utf-8") as f:
            json.dump(all_schema_data, f, indent=4, ensure_ascii=False)
        print(f"\n✅ Combined schema saved to: {combined_path}")

if __name__ == "__main__":
    folder_path = "./CSV_Files"  # Update to your CSV folder path
    processor = CSVSchemaProcessor(folder_path)
    processor.process()
