import os
import re
import json
from typing import Dict, Any, Optional
from dotenv import load_dotenv

from langgraph.graph import StateGraph, END
from langchain.prompts import PromptTemplate
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_community.chat_models import AzureChatOpenAI

load_dotenv()


class AmbiguityAgent:
    def __init__(self, schema_path: str):
        self.llm = AzureChatOpenAI(
            azure_endpoint=os.getenv('AZURE_OPENAI_ENDPOINT'),
            api_version=os.getenv('OPENAI_API_VERSION'),
            temperature=0.4,
            max_tokens=None,
            timeout=None,
            azure_deployment=os.getenv('GPT_MODEL'),
            api_key=os.getenv('AZURE_OPENAI_API_KEY'),
            max_retries=2,
        )
        self.schema_json_string = self._load_schema(schema_path)
        self.ambiguity_detection_prompt = PromptTemplate(
        input_variables=["query", "schema"],
        template=(
            "You are an assistant that evaluates user queries against a database table.\n"
            "Schema:\n{schema}\n\n"
            "Only flag queries as ambiguous if a typical user would be genuinely unsure what is meant, or if there are multiple plausible interpretations. "
            "If a reasonable default interpretation exists, treat the query as clear. Do not suggest improvements unless the query is truly ambiguous.\n\n"
            "Return a JSON object with:\n"
            "  ambiguous: true or false\n"
            "  clarification: null (if not ambiguous), or a string suggesting what the user should clarify\n"
            "  suggestions: a list of example queries or improvements tailored to this schema (if ambiguous), or null if not ambiguous\n"
            "  feedback: a brief explanation of your reasoning (1-2 sentences)\n\n"
            "User Query:\n"
            "{query}\n"
            "JSON:"
        )
)
        self.reframe_prompt = PromptTemplate(
            input_variables=["query"],
            template="Please reframe the following query for clarity and completeness: {query}"
        )
        self.graph = self._build_graph()

    def _load_schema(self, path: str) -> str:
        with open(path) as f:
            return f.read()

    @staticmethod
    def _get_content(response):
        if hasattr(response, "content"):
            return response.content.strip()
        elif isinstance(response, str):
            return response.strip()
        raise ValueError(f"Unknown LLM response type: {type(response)}")

    @staticmethod
    def extract_json(text):
        match = re.search(r'\{.*\}', text, re.DOTALL)
        if match:
            return match.group(0)
        else:
            raise ValueError("No JSON object found in LLM output.")

    # --- Node methods ---
    def detect_ambiguity(self, state: dict):
        prompt = self.ambiguity_detection_prompt.format_prompt(
            query=state["user_query"], schema=state["schema"]
        ).to_string()
        print("PROMPT SENT TO LLM:\n", prompt)
        response = self.llm([HumanMessage(content=prompt)])
        content = self._get_content(response)
        try:
            json_str = self.extract_json(content)
            data = json.loads(json_str)
            state["ambiguous"] = data.get("ambiguous", False)
            state["clarification"] = data.get("clarification")
            state["suggestions"] = data.get("suggestions")
            state["feedback"] = data.get("feedback")
        except Exception as e:
            print("ERROR PARSING LLM OUTPUT:", e)
            state["ambiguous"] = False
            state["clarification"] = None
            state["suggestions"] = None
            state["feedback"] = None
        return state

    def ask_for_clarification(self, state: dict):
        clarification = state.get("clarification")
        suggestions = state.get("suggestions")
        feedback = state.get("feedback")
        print(f"Ambiguity agent: {clarification}")
        if suggestions:
            print(f"Suggestions: {suggestions}")
        if feedback:
            print(f"Feedback: {feedback}")
        state["clarification"] = clarification
        return state

    def receive_clarification(self, state: dict):
        user_input = input("User (clarification): ")
        state["user_query"] += f' [Clarified: {user_input}]'
        state["clarification"] = user_input
        return state

    def reframe_query(self, state: dict):
        prompt = self.reframe_prompt.format_prompt(query=state["user_query"]).to_string()
        response = self.llm.invoke([HumanMessage(content=prompt)])
        state["reframed_query"] = self._get_content(response)
        print(f"Ambiguity agent (reframed query): {state['reframed_query']}")
        return state

    def pass_query(self, state: dict):
        state["reframed_query"] = state["user_query"]
        print(f"Ambiguity agent (passed query): {state['reframed_query']}")
        return state

    def ambiguity_decision(self, state):
        return "ask_for_clarification" if state.get("ambiguous") else "pass_query"

    def _build_graph(self):
        graph = StateGraph(dict)
        graph.add_node("detect_ambiguity", self.detect_ambiguity)
        graph.add_node("ask_for_clarification", self.ask_for_clarification)
        graph.add_node("receive_clarification", self.receive_clarification)
        graph.add_node("reframe_query", self.reframe_query)
        graph.add_node("pass_query", self.pass_query)

        graph.set_entry_point("detect_ambiguity")
        graph.add_conditional_edges("detect_ambiguity", self.ambiguity_decision)
        graph.add_edge("ask_for_clarification", "receive_clarification")
        graph.add_edge("receive_clarification", "reframe_query")
        graph.add_edge("reframe_query", END)
        graph.add_edge("pass_query", END)
        return graph.compile()

    def run(self, user_query: str):
        state = {
            "user_query": user_query,
            "schema": self.schema_json_string,
            "clarification": None,
            "reframed_query": None,
            "ambiguous": None,
            "suggestions": None,
            "feedback": None
        }
        result = self.graph.invoke(state)
        print("\n--- Final Output ---")
        print("Reframed Query:", result["reframed_query"])
        return result["reframed_query"]


if __name__ == "__main__":
    print("=== Ambiguity Agent Demo ===")
    user_query = input("User: ")
    agent = AmbiguityAgent(schema_path="./Files/schema.json")
    agent.run(user_query)
