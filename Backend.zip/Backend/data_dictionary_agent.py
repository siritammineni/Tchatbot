import os
import re
import json
import pandas as pd
from dotenv import load_dotenv
from typing import TypedDict, Optional

from langchain_openai import AzureChatOpenAI
from langchain.tools import tool
from langgraph.graph import StateGraph, END

class DataDictionaryGenerator:
    class MyState(TypedDict):
        csv_path: str
        csv_preview: Optional[str]
        dd_json: Optional[str]

    def __init__(self, 
                 csv_input_dir="CSV_Files",
                 save_dir="./Files"):
        self.CSV_INPUT_DIR = csv_input_dir
        self.SAVE_DIR = save_dir
        os.makedirs(self.SAVE_DIR, exist_ok=True)
        load_dotenv()

        self.llm = AzureChatOpenAI(
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT_DOC_COMP"),
            deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
            temperature=0.3,
        )
        self.flow = self.build_graph()

    @staticmethod
    def extract_json(text):
        match = re.search(r"```(?:json)?\s*(.*?)\s*```", str(text).strip(), re.DOTALL | re.IGNORECASE)
        return match.group(1).strip() if match else str(text).strip().strip("`")

    def dd_tool(self, csv_preview: str) -> str:
        """Generate a data dictionary JSON from a CSV preview."""
        prompt = (
            "Given the CSV preview below, generate a JSON data dictionary. "
            "Do NOT use speculative language like 'may be', 'can be', 'might', or 'could'. "
            "For each column, provide column_name, relation_with_other_columns, and column_description. "
            "Output only JSON as a dict keyed by column name.\n\nCSV Preview:\n" + csv_preview
        )
        resp = self.llm.invoke(prompt)
        return self.extract_json(resp.content if hasattr(resp, 'content') else resp)

    @staticmethod
    def get_csv_preview(csv_path, nrows=5):
        return pd.read_csv(csv_path, nrows=nrows).to_csv(index=False)

    def preview_node(self, state: MyState) -> MyState:
        state["csv_preview"] = self.get_csv_preview(state["csv_path"])
        return state

    def dd_agent_node(self, state: MyState) -> MyState:
        state["dd_json"] = self.dd_tool(state["csv_preview"])
        return state

    def build_graph(self):
        graph = StateGraph(self.MyState)
        graph.add_node("preview", self.preview_node)
        graph.add_node("dd_agent", self.dd_agent_node)
        graph.add_edge("preview", "dd_agent")
        graph.add_edge("dd_agent", END)
        graph.set_entry_point("preview")
        return graph.compile()

    def process_single_csv(self, csv_path):
        result = self.flow.invoke({"csv_path": csv_path})
        dd_json = result["dd_json"]
        try:
            dd_dict = json.loads(dd_json)
        except Exception:
            dd_dict = dd_json  # fallback: save as string
        return dd_dict

    def run(self):
        # List all CSV files in the directory
        csv_files = [f for f in os.listdir(self.CSV_INPUT_DIR) if f.lower().endswith(".csv")]
        if not csv_files:
            print(f"No CSV files found in {self.CSV_INPUT_DIR}")
            return

        all_dd_results = {}

        for csv_filename in csv_files:
            csv_path = os.path.join(self.CSV_INPUT_DIR, csv_filename)
            print(f"Processing: {csv_filename}")
            try:
                dd_dict = self.process_single_csv(csv_path)
                all_dd_results[os.path.splitext(csv_filename)[0]] = dd_dict
                print(f"  ✔ Data dictionary generated.")
            except Exception as e:
                print(f"  ✖ Failed to process {csv_filename}: {e}")

        # Save as single JSON file
        save_path = os.path.join(self.SAVE_DIR, "data_dictionary.json")
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(all_dd_results, f, indent=2, ensure_ascii=False)

        print(f"\nAll data dictionaries saved as: {save_path}")

if __name__ == "__main__":
    ddg = DataDictionaryGenerator()
    ddg.run()
