import os
import re
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Any, Optional
 
# Try both imports for AzureChatOpenAI for compatibility
try:
    from langchain_openai import AzureChatOpenAI
except ImportError:
    from langchain.chat_models import AzureChatOpenAI
 
from dotenv import load_dotenv
from langgraph.graph import StateGraph, END
 
load_dotenv()
 
class VizAssistant:
    STANDARD_COLORS = {
        'bar': '#0072C6',
        'line': '#E15759',
        'scatter': '#76B7B2',
        'pie': ['#0072C6', '#E15759', '#76B7B2', '#F28E2B', '#59A14F'],
        'hist': '#4E79A7',
        'box': '#59A14F',
        'area': ['#0072C6', '#E15759', '#76B7B2', '#F28E2B', '#59A14F'],
        'heatmap': 'Blues'
    }
 
    CHART_KEYWORDS = {
        'bar': ['bar', 'bar chart', 'bar graph'],
        'line': ['line', 'line chart', 'line plot'],
        'scatter': ['scatter', 'scatter plot', 'scatter chart'],
        'pie': ['pie', 'pie chart', 'pie graph'],
        'hist': ['hist', 'histogram', 'hist plot', 'hist chart'],
        'box': ['box', 'box plot', 'box chart'],
        'area': ['area', 'area chart', 'area plot'],
        'heatmap': ['heatmap', 'heat map'],
    }
 
    PLOTTING_FUNCTIONS = {
        "bar": "standard_bar_plot(x, y, title, xlabel, ylabel, legend_label=None)",
        "line": "standard_line_plot(x, y, title, xlabel, ylabel, legend_label=None)",
        "scatter": "standard_scatter_plot(x, y, title, xlabel, ylabel, legend_label=None)",
        "pie": "standard_pie_plot(values, labels, title)",
        "hist": "standard_hist_plot(data, bins=10, title, xlabel, ylabel, color=None)",
        "box": "standard_box_plot(data, labels=None, title, ylabel, color=None)",
        "area": "standard_area_plot(x, ys, labels=None, title, xlabel, ylabel, colors=None)",
        "heatmap": "standard_heatmap(data, title, xlabel, ylabel, cmap=None, annot=True)"
    }
 
    def __init__(self, df: pd.DataFrame, schema: dict, llm: Optional[Any] = None):
        self.df = df
        self.schema = schema
        self.llm = llm or self._init_llm()
        self.graph = self._build_graph()
 
    def _init_llm(self):
        return AzureChatOpenAI(
            azure_endpoint=os.getenv('AZURE_OPENAI_ENDPOINT'),
            api_version=os.getenv('OPENAI_API_VERSION'),
            temperature=0.4,
            max_tokens=None,
            timeout=None,
            azure_deployment=os.getenv('GPT_MODEL'),
            api_key=os.getenv('AZURE_OPENAI_API_KEY'),
            max_retries=2,
        )
 
    # --------- Plotting Functions ------------
 
    @staticmethod
    def apply_standard_style(ax):
        if hasattr(ax, "grid"):
            ax.grid(axis='y', linestyle='--', alpha=0.7)
        if hasattr(ax, "title"):
            ax.title.set_fontsize(16)
            ax.title.set_fontweight('bold')
        if hasattr(ax, "xaxis") and hasattr(ax.xaxis, "label"):
            ax.xaxis.label.set_fontsize(12)
        if hasattr(ax, "yaxis") and hasattr(ax.yaxis, "label"):
            ax.yaxis.label.set_fontsize(12)
 
    def standard_bar_plot(self, x, y, title, xlabel, ylabel, legend_label=None):
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.bar(x, y, color=self.STANDARD_COLORS['bar'], edgecolor='black', label=legend_label)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        if legend_label:
            ax.legend()
        self.apply_standard_style(ax)
        plt.tight_layout()
        plt.show()
 
    def standard_line_plot(self, x, y, title, xlabel, ylabel, legend_label=None):
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(x, y, color=self.STANDARD_COLORS['line'], marker='o', label=legend_label)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        if legend_label:
            ax.legend()
        self.apply_standard_style(ax)
        plt.tight_layout()
        plt.show()
 
    def standard_scatter_plot(self, x, y, title, xlabel, ylabel, legend_label=None):
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.scatter(x, y, color=self.STANDARD_COLORS['scatter'], label=legend_label)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        if legend_label:
            ax.legend()
        self.apply_standard_style(ax)
        plt.tight_layout()
        plt.show()
 
    def standard_pie_plot(self, values, labels, title):
        fig, ax = plt.subplots(figsize=(7, 7))
        colors = self.STANDARD_COLORS['pie'][:len(values)]
        ax.pie(
            values,
            labels=labels,
            colors=colors,
            autopct='%1.1f%%',
            startangle=90,
            textprops={'fontsize': 12}
        )
        ax.set_title(title, fontsize=16, fontweight='bold')
        plt.tight_layout()
        plt.show()
 
    def standard_hist_plot(self, data, bins=10, title="Histogram", xlabel="", ylabel="Frequency", color=None):
        color = self.STANDARD_COLORS['hist']
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.hist(data, bins=bins, color=color, edgecolor='black', alpha=0.7)
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        self.apply_standard_style(ax)
        plt.tight_layout()
        plt.show()
 
    def standard_box_plot(self, data, labels=None, title="Box Plot", ylabel="", color=None):
        color = self.STANDARD_COLORS['box']
        fig, ax = plt.subplots(figsize=(8, 5))
        box = ax.boxplot(data, patch_artist=True, labels=labels)
        for patch in box['boxes']:
            patch.set_facecolor(color)
        ax.set_title(title)
        ax.set_ylabel(ylabel)
        self.apply_standard_style(ax)
        plt.tight_layout()
        plt.show()
 
    def standard_area_plot(self, x, ys, labels=None, title="Area Plot", xlabel="", ylabel="", colors=None):
        colors = self.STANDARD_COLORS['area']
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.stackplot(x, *ys, labels=labels, colors=colors[:len(ys)], alpha=0.7)
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        if labels:
            ax.legend()
        self.apply_standard_style(ax)
        plt.tight_layout()
        plt.show()
 
    def standard_heatmap(self, data, title="Heatmap", xlabel="", ylabel="", cmap=None, annot=True):
        cmap = self.STANDARD_COLORS['heatmap']
        fig, ax = plt.subplots(figsize=(8, 6))
        sns.heatmap(data, ax=ax, cmap=cmap, annot=annot, fmt=".2f", linewidths=0.5, cbar=True)
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        self.apply_standard_style(ax)
        plt.tight_layout()
        plt.show()
 
    # --------- Chart Type Detection ------------
 
    def detect_chart_type(self, user_query: str) -> str:
        """Detect chart type from user query. Defaults to 'bar' if none found."""
        user_query_lc = user_query.lower()
        for chart_type, keywords in self.CHART_KEYWORDS.items():
            for kw in keywords:
                if re.search(r'\b' + re.escape(kw) + r'\b', user_query_lc):
                    return chart_type
        return 'bar'
 
    # --------- LangGraph Nodes ------------
 
    def llm_generate_code_node(self, state):
        user_query = state["user_query"]
        schema = state["schema"]
        selected_graph_type = state["selected_graph_type"].strip().lower()
        df_variable_name = "df"
        llm = state["llm"]
 
        all_functions_text = "\n    ".join(self.PLOTTING_FUNCTIONS.values())
 
        if isinstance(schema, dict):
            schema_str = ', '.join([f"{k}: {v}" for k, v in schema.items()])
        else:
            schema_str = str(schema)
 
        prompt = f"""
You are a Python data visualization assistant.
 
You will be given:
 
A pandas DataFrame named {df_variable_name} with schema: {schema_str}
The selected graph type for this query is: "{selected_graph_type}"
The following standard plotting functions are available:
{all_functions_text}
The user query is:
 
{user_query}
 
Write ONLY Python code (no explanations) that will plot the answer to the query using the provided standard plotting functions and the DataFrame {df_variable_name}.
 
Use ONLY the plotting function that matches the selected graph type: "{selected_graph_type}". For example, if the graph type is "bar", use standard_bar_plot; if "line", use standard_line_plot, etc.
 
DO NOT use any other plotting function or method.
"""
 
        response = llm.invoke(prompt)
        code = response.content if hasattr(response, "content") else str(response)
        state["generated_code"] = code
        return state
 
    def clean_code_node(self, state):
        code = state["generated_code"]
        code = code.strip()
        code = re.sub(r"^```(?:python)?\s*", "", code)
        code = re.sub(r"\s*```$", "", code)
        state["clean_code"] = code
        return state
 
    def exec_code_node(self, state):
        code = state["clean_code"]
        df = state["df"]
 
        safe_globals = {
            'standard_bar_plot': self.standard_bar_plot,
            'standard_line_plot': self.standard_line_plot,
            'standard_scatter_plot': self.standard_scatter_plot,
            'standard_pie_plot': self.standard_pie_plot,
            'standard_hist_plot': self.standard_hist_plot,
            'standard_box_plot': self.standard_box_plot,
            'standard_area_plot': self.standard_area_plot,
            'standard_heatmap': self.standard_heatmap,
            'apply_standard_style': self.apply_standard_style,
            'df': df,
            'plt': plt,
            'pd': pd,
            'sns': sns,
            'STANDARD_COLORS': self.STANDARD_COLORS,
        }
        try:
            exec(code, safe_globals)
            state["exec_error"] = None
        except Exception as e:
            state["exec_error"] = str(e)
            print("Error executing LLM-generated code:", e)
        return state
 
    def handle_error_node(self, state):
        print("Execution error:", state["exec_error"])
        return state
 
    # --------- LangGraph Build ------------
 
    def _build_graph(self):
        graph = StateGraph(dict)
        graph.add_node("llm_generate_code", self.llm_generate_code_node)
        graph.add_node("clean_code", self.clean_code_node)
        graph.add_node("exec_code", self.exec_code_node)
        graph.add_node("handle_error", self.handle_error_node)
        graph.set_entry_point("llm_generate_code")
        graph.add_edge("llm_generate_code", "clean_code")
        graph.add_edge("clean_code", "exec_code")
 
        def exec_decision(state):
            return "handle_error" if state.get("exec_error") else END
 
        graph.add_conditional_edges("exec_code", exec_decision)
        graph.add_edge("handle_error", END)
        return graph.compile()
 
    # --------- Main Run ------------
 
    def run(self):
        print("\nWelcome to the Data Visualization Assistant!")
        print("Type your query about the data (e.g., 'Show customer count by state as a bar chart').")
        print("If you don't specify a chart type, a bar chart will be used by default.\n")
        user_query = input("Enter your query: ").strip()
        if not user_query:
            print("No query entered. Exiting.")
            return
 
        selected_graph_type = self.detect_chart_type(user_query)
        print(f"Detected chart type: {selected_graph_type.title()}")
 
        state = {
            "df": self.df,
            "schema": self.schema,
            "user_query": user_query,
            "llm": self.llm,
            "selected_graph_type": selected_graph_type,
            "generated_code": None,
            "clean_code": None,
            "exec_error": None
        }
 
        result = self.graph.invoke(state)
        if result.get("exec_error"):
            print("Failed to plot due to error:", result["exec_error"])
 
# --------- Use your provided data ------------
 
if __name__ == "__main__":
    data = [
        {"customer_state": "SP", "customer_count": 41746},
        {"customer_state": "RJ", "customer_count": 12852},
        {"customer_state": "MG", "customer_count": 11635},
        {"customer_state": "RS", "customer_count": 5466},
        {"customer_state": "PR", "customer_count": 5045},
        {"customer_state": "SC", "customer_count": 3637},
        {"customer_state": "BA", "customer_count": 3380},
        {"customer_state": "DF", "customer_count": 2140},
        {"customer_state": "ES", "customer_count": 2033},
        {"customer_state": "GO", "customer_count": 2020}
    ]
 
    df_states = pd.DataFrame(data)
 
    schema_states = {
        "customer_state": "string",
        "customer_count": "int"
    }
 
    assistant = VizAssistant(df_states, schema_states)
    assistant.run()