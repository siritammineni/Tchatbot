import os
from dotenv import load_dotenv
from typing import TypedDict, List, Annotated
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.tools import Tool
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode
from langgraph.graph.message import add_messages
import pandas as pd
import PyPDF2
import glob

class DomainKnowledgeProcessor:
    class AgentState(TypedDict):
        filepath: str
        domain_msg: str
        messages: Annotated[List, add_messages]

    def __init__(self, input_folder="CSV_Files", output_file="./Files/domain_kb.txt"):
        load_dotenv()
        self.input_folder = input_folder
        self.output_file = output_file

        # Load environment variables for Azure OpenAI
        self.OPENAI_API_VERSION = os.getenv("OPENAI_API_VERSION")
        self.GPT_MODEL = os.getenv("GPT_MODEL")
        self.AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")

        self.llm = AzureChatOpenAI(
            openai_api_version=self.OPENAI_API_VERSION,
            azure_deployment=self.GPT_MODEL,
            azure_endpoint=self.AZURE_OPENAI_ENDPOINT,
            openai_api_key=self.AZURE_OPENAI_API_KEY,
            temperature=0.0
        )

        # Register tool functions as Tool objects with descriptions
        self.tools = [
            Tool(
                name="extract_csv",
                func=self.extract_csv,
                description="Extract contents of a CSV file and create a data dictionary."
            ),
            Tool(
                name="extract_pdf",
                func=self.extract_pdf,
                description="Extract content from a PDF file for further analysis."
            ),
            Tool(
                name="generate_domain_kb",
                func=self.generate_domain_kb,
                description="Generate domain knowledge base from extracted data."
            )
        ]

        self.llm_with_tools = self.llm.bind_tools(tools=self.tools)
        self.app = self._build_graph()

    def extract_csv(self, filename: str) -> str:
        """Extract contents of CSV file and create a data dictionary."""
        print("IN CSV TOOL")
        if not filename.endswith(".csv"):
            return "Error: file not CSV"
        try:
            data = pd.read_csv(filename)
            data = data.head(10)
            system_prompt = """
            You are an AI assistant. Your task is to create a data dictionary using the CSV file output. The data dictionary should include:
            - name: name of the column
            - description: short description about the columns
            - relation: relation with other columns
            and it should be in a form of a dictionary with the above key-value pairs"""
            user_msg = f"Create a data dictionary for this CSV data:\nColumns: {list(data.columns)}\nSample data:\n{data.to_string()}"
            messages = [
                SystemMessage(content=system_prompt),
                HumanMessage(content=user_msg)
            ]
            response = self.llm.invoke(messages)
            return response.content
        except Exception as e:
            return f"Error processing CSV {str(e)}"

    def extract_pdf(self, filename: str) -> str:
        """Extract content from PDF file for further analysis."""
        print("IN PDF TOOL")
        if not filename.endswith(".pdf"):
            return "Error: file not a PDF file"
        try:
            with open(filename, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(f)
                text = ""
                for page in pdf_reader.pages:
                    text += page.extract_text() + "\n"
            return text
        except Exception as e:
            return f"Error processing PDF {str(e)}"

    def generate_domain_kb(self, msg: str) -> str:
        """Generate domain knowledge base from extracted data."""
        print("IN THE KB TOOL")
        system_prompt = """
        You are a Domain Document Creator Agent. Your task is to generate detailed domain understanding document from input data which explain the data story following below instructions
        - You should understand the relations between columns and understand the motive of that data.
        - Do not provide me data structure informatino like data type or null values etc.
        - Your goal is to provide a domain document so that it helps a person to understand the given data properly and understand the importance of each column.
        - Also provide an analysis of data

        The output should be structured as:
        **Title** - title of the content
        **Relation** - relation among the columns/data elements
        **Analysis** - summary of the data
        """
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=msg)
        ]
        response = self.llm.invoke(messages)
        print("RESPONSE FROM PDF\n", response.content)
        return response.content

    def tool_node(self, state:AgentState):
        print("IN THE TOOL NODE")
        messages = state.get("messages", [])
        if not messages:
            return state
        last_message = messages[-1]
        if not hasattr(last_message, 'tool_calls') or not last_message.tool_calls:
            return state
        tool_node = ToolNode(self.tools)
        result = tool_node.invoke(state)
        for tool_call in last_message.tool_calls:
            if tool_call["name"] == "generate_domain_kb":
                for msg in result["messages"]:
                    if hasattr(msg, "content") and isinstance(msg.content, str):
                        if "**Title**" in msg.content and "**Relation**" in msg.content and "**Analysis**" in msg.content:
                            result["domain_msg"] = msg.content
                            print("DOMAIN KB GENERATED")
                            break
        return result

    def agent_node(self, state:AgentState) -> AgentState:
        print("IN AGENT NODE")
        if state.get("domain_msg") and state["domain_msg"].strip():
            print("DOMAIN KB ALREADY GENERATED")
            return state
        file_path = state["filepath"]
        messages = state.get("messages", [])
        extracted_data = None
        for msg in messages:
            if hasattr(msg, "content") and isinstance(msg.content, str):
                if "Title:" in msg.content or "**Title**" in msg.content:
                    return {
                        "filepath": state["filepath"],
                        "domain_msg": msg.content,
                        "messages": state["messages"]
                    }
                elif len(msg.content) > 100 and ("column" in msg.content.lower() or "data" in msg.content.lower()):
                    extracted_data = msg.content
        if extracted_data:
            system_prompt = SystemMessage(content=f"""
            You have already extracted data from the file {file_path}.
            Now use the 'generate_domain_kb' tool with the extracted data to create the final knowledge base.
            The output should contain:
            - **Title** - title of the content
            - **Relation** - relation among the columns/data elements
            - **Analysis** - summary of the data              
            """)
            messages = [system_prompt, HumanMessage(content=f"Generate domain knowledge base from this extracted data: {extracted_data}")]
        else:
            system_prompt = SystemMessage(content=f"""
            You are a Domain Deciding Agent. Your task is to extract data from the file {file_path}.
            - Check the file extension to determin the type
            - If its a .csv file, use the 'extract_csv' tool
            - If its a .pdf file, use the 'extract_pdf' tool
            - Extract the data first, then we will generate the knowledge base in the next step
            """)
            messages = [system_prompt, HumanMessage(content=f"Extract data from the file: {file_path}")]
        print("MESSAGEES IN THE AGENT NODE:", len(messages))
        response = self.llm_with_tools.invoke(messages)
        print("RESPONSE CONTENT IN AGENT NODE:\n", response.content if hasattr(response, 'content') else "No Content")
        print("TOOL CALLS:\n", response.tool_calls if hasattr(response, 'tool_calls') else "NO tool calls")
        return {
            "filepath": state["filepath"],
            "domain_msg": state.get("domain_msg", ""),
            "messages": state["messages"] + [response]
        }

    def should_continue(self, state:AgentState):
        print("IN THE SHOULD_CONTINUE NODE")
        messages = state.get("messages", [])
        if not messages:
            print("No messages, continuing")
            return "continue"
        last_message = messages[-1]
        print(f"Last message type: {type(last_message)}")
        if state.get("domain_msg") and state["domain_msg"].strip():
            print("Domain KB generated")
            return "end"
        if hasattr(last_message, 'tool_calls') and last_message.tool_calls:
            print("Has tool calls")
            return "continue"
        else:
            print("No tool calls")
            return "end"

    def save_txt(self, content: str):
        os.makedirs(os.path.dirname(self.output_file), exist_ok=True)
        with open(self.output_file, "w", encoding="utf-8") as f:
            f.write(str(content))

    def _build_graph(self):
        graph = StateGraph(self.AgentState)
        graph.add_node("agent", self.agent_node)
        graph.add_node("tools_node", self.tool_node)
        graph.add_conditional_edges(
            "agent",
            self.should_continue,
            {
                "continue": "tools_node",
                "end": END
            }
        )
        graph.add_edge("tools_node", "agent")
        graph.set_entry_point("agent")
        return graph.compile()

    def process_files(self, file_list: List[str]):
        output_res = f"{'='*100}\n"
        for i in file_list:
            print(f"Processing file: {i}")
            result = self.app.invoke({
                "filepath": i,
                "domain_msg": "",
                "messages": []
            })
            output_res += f"""**File** - {i}\n\n{result["domain_msg"]}\n{'='*100}\n"""
        self.save_txt(output_res)

    def get_all_files(self):
        # Get all CSV and PDF files in input_folder
        csv_files = glob.glob(os.path.join(self.input_folder, "*.csv"))
        pdf_files = glob.glob(os.path.join(self.input_folder, "*.pdf"))
        return csv_files + pdf_files

    def run(self):
        file_list = self.get_all_files()
        print("Files to process:", file_list)
        self.process_files(file_list)

# ==========================
# Example usage (main block)
# ==========================
if __name__ == "__main__":
    processor = DomainKnowledgeProcessor(input_folder="CSV_Files", output_file="./Files/domain_kb.txt")
    processor.run()
