import os
import re
import json
from dotenv import load_dotenv
load_dotenv()
from typing import Dict, Any

from langchain.prompts import PromptTemplate
from langchain_core.messages import HumanMessage
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END

# --- Prompt ---
classification_prompt = PromptTemplate(
    input_variables=["reframed_query"],
    template=(
        "You are an assistant that decides if a user's query should be answered with a graph/visualization or just with text.\n"
        "Given the user's clarified query below, answer as follows:\n"
        "1. In one word, state 'graph' if the query requires a graphical representation (such as a chart, bar graph, line graph, etc.), or 'no graph' if a text/table answer is sufficient.\n"
        "2. Briefly (1-2 sentences) explain your reasoning.\n\n"
        "Query:\n"
        "{reframed_query}\n"
        "Answer:"
    )
)

class GraphRequirementClassifier:
    def __init__(self, llm=None):
        self.llm = llm or self._init_llm()
        self.graph = self._build_graph()
    
    def _init_llm(self):
        return AzureChatOpenAI(
            azure_endpoint=os.getenv('AZURE_OPENAI_ENDPOINT'),
            api_version=os.getenv('OPENAI_API_VERSION'),
            temperature=0.4,
            max_tokens=None,
            timeout=None,
            azure_deployment=os.getenv('GPT_MODEL'),
            api_key=os.getenv('AZURE_OPENAI_API_KEY'),
            max_retries=2,
        )
    
    @staticmethod
    def _get_content(response):
        if hasattr(response, "content"):
            return response.content.strip()
        elif isinstance(response, str):
            return response.strip()
        raise ValueError(f"Unknown LLM response type: {type(response)}")
    
    def classify_graph_need(self, state: dict):
        reframed_query = state["reframed_query"]
        prompt = classification_prompt.format_prompt(reframed_query=reframed_query).to_string()
        response = self.llm.invoke([HumanMessage(content=prompt)])
        content = self._get_content(response)
        print("\nClassification agent output:\n", content)
        # Simple parsing
        lines = [line.strip() for line in content.split('\n') if line.strip()]
        if lines:
            if "no graph" in lines[0].lower():
                state['graph_required'] = "no graph"
            elif "graph" in lines[0].lower():
                state['graph_required'] = "graph"
            else:
                state['graph_required'] = lines[0].lower()
            state['graph_explanation'] = lines[1] if len(lines) > 1 else ""
        else:
            state['graph_required'] = "unknown"
            state['graph_explanation'] = "Could not parse LLM output."
        return state

    @staticmethod
    def print_graph_result(state: dict):
        print("\n--- Classification Result ---")
        print("Graph Required:", state.get("graph_required"))
        print("Reasoning:", state.get("graph_explanation"))
        return state

    def _build_graph(self):
        graph = StateGraph(dict)
        # Bind the instance methods
        graph.add_node("classify_graph_need", self.classify_graph_need)
        graph.add_node("print_graph_result", self.print_graph_result)
        graph.set_entry_point("classify_graph_need")
        graph.add_edge("classify_graph_need", "print_graph_result")
        graph.add_edge("print_graph_result", END)
        return graph.compile()
    
    def run(self, reframed_query: str):
        state = {
            "reframed_query": reframed_query,
            "llm": self.llm,
            "graph_required": None,
            "graph_explanation": None
        }
        result = self.graph.invoke(state)
        # Optionally, you could return result here instead of just printing
        return {
            "graph_required": result.get("graph_required"),
            "graph_explanation": result.get("graph_explanation")
        }

if __name__ == "__main__":
    classifier = GraphRequirementClassifier()
    reframed_query = input("Enter the clarified/reframed query: ")
    result = classifier.run(reframed_query)
    # Results also printed inside print_graph_result
    # Optionally print here again
    # print(result)
