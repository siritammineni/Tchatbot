import os
from dotenv import load_dotenv
from typing import Dict, Any
from langchain.prompts import PromptTemplate
from langchain_core.messages import HumanMessage
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, END

load_dotenv()

class GraphTypeSelector:
    def __init__(self):
        self.graph_selection_prompt = PromptTemplate(
            input_variables=["reframed_query"],
            template=(
                "You are an assistant that analyzes a user's query about data visualization.\n"
                "If the user query mentions any specific graph, chart, or plot type (such as line chart, bar graph, pie plot, scatter chart, etc.), extract and return the exact graph type mentioned in the query.\n"
                "If the user does not mention any graph, chart, or plot type, suggest 'Bar Graph' by default.\n"
                "Output ONLY in this format:\n"
                "graph_type: <type of graph>\n"
                "reasoning: <short explanation>\n\n"
                "User's query:\n"
                "{reframed_query}\n"
                "Answer:"
            )
        )
        self.llm = AzureChatOpenAI(
            azure_endpoint=os.getenv('AZURE_OPENAI_ENDPOINT'),
            api_version=os.getenv('OPENAI_API_VERSION'),
            temperature=0.4,
            max_tokens=None,
            timeout=None,
            azure_deployment=os.getenv('GPT_MODEL'),
            api_key=os.getenv('AZURE_OPENAI_API_KEY'),
            max_retries=2,
        )
        self.graph = self._build_graph()
        self.app = self.graph.compile()

    def _select_graph_type_llm(self, state: dict):
        reframed_query = state["reframed_query"]
        prompt_str = self.graph_selection_prompt.format_prompt(
            reframed_query=reframed_query
        ).to_string()
        response = self.llm.invoke([HumanMessage(content=prompt_str)])
        content = response.content.strip() if hasattr(response, "content") else str(response).strip()
        print("\nGraph selection agent output:\n", content)
        # Parse
        lines = [line.strip() for line in content.split('\n') if line.strip()]
        for line in lines:
            if line.lower().startswith("graph_type:"):
                state["graph_type"] = line.split(":", 1)[1].strip()
            elif line.lower().startswith("reasoning:"):
                state["graph_reasoning"] = line.split(":", 1)[1].strip()
        return state

    def _print_graph_selection_result(self, state: dict):
        print("\n--- Graph Selection Result ---")
        print("Graph Type:", state.get("graph_type"))
        print("Reasoning:", state.get("graph_reasoning"))
        return state

    def _build_graph(self):
        graph = StateGraph(dict)
        graph.add_node("select_graph_type_llm", self._select_graph_type_llm)
        graph.add_node("print_graph_selection_result", self._print_graph_selection_result)
        graph.set_entry_point("select_graph_type_llm")
        graph.add_edge("select_graph_type_llm", "print_graph_selection_result")
        graph.add_edge("print_graph_selection_result", END)
        return graph

    def select_graph_type(self, reframed_query: str) -> Dict[str, Any]:
        state = {
            "reframed_query": reframed_query,
            "graph_type": None,
            "graph_reasoning": None
        }
        result = self.app.invoke(state)
        return {
            "graph_type": result.get("graph_type"),
            "graph_reasoning": result.get("graph_reasoning")
        }

# --- Example Usage ---

if __name__ == "__main__":
    selector = GraphTypeSelector()
    reframed_query = input("Enter the clarified/reframed query: ")
    result = selector.select_graph_type(reframed_query)
    print("\n== Final Result ==")
    print("Graph Type:", result["graph_type"])
    print("Reasoning:", result["graph_reasoning"])
