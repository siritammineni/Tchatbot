import os
import json
import re
import csv
import sqlite3
import pandas as pd
from typing import TypedDict
from dotenv import load_dotenv
from langchain_core.runnables import RunnableLambda
from langgraph.graph import StateGraph
from langchain_openai import AzureChatOpenAI

class SQLQueryGenerator:
    class GraphState(TypedDict):
        schema_data: dict
        data_dict: dict
        domain_knowledge: str
        question: str
        sql_query: str
        output_query: str  # For natural language answer

    def __init__(
        self, 
        csv_folder: str, 
        files_folder: str,
        azure_api_key_env='AZURE_OPENAI_API_KEY',
        azure_endpoint_env='AZURE_OPENAI_ENDPOINT_DOC_COMP',
        azure_deployment_env='AZURE_OPENAI_DEPLOYMENT_NAME',
        azure_version_env='AZURE_OPENAI_API_VERSION'
    ):
        load_dotenv()
        self.csv_folder = csv_folder
        self.files_folder = files_folder
        self.llm = AzureChatOpenAI(
            api_key=os.getenv(azure_api_key_env),
            azure_endpoint=os.getenv(azure_endpoint_env),
            deployment_name=os.getenv(azure_deployment_env),
            api_version=os.getenv(azure_version_env),
            temperature=0.2,
        )
        self.conn = None

    @staticmethod
    def clean_sql_response(query: str) -> str:
        cleaned = re.sub(r"```sql|```|```sql```|```sql\n", "", query, flags=re.IGNORECASE).strip()
        return cleaned

    def load_csvs_into_memory(self) -> sqlite3.Connection:
        conn = sqlite3.connect(":memory:")
        cursor = conn.cursor()
        for file in os.listdir(self.csv_folder):
            if file.endswith('.csv'):
                table_name = os.path.splitext(file)[0]
                with open(os.path.join(self.csv_folder, file), 'r', newline='', encoding='utf-8') as csvfile:
                    reader = csv.reader(csvfile)
                    headers = next(reader)
                    headers = [re.sub(r'\W+', '_', h) for h in headers]
                    cursor.execute(f"CREATE TABLE {table_name} ({', '.join(headers)})")
                    for row in reader:
                        placeholders = ', '.join('?' * len(row))
                        cursor.execute(f"INSERT INTO {table_name} VALUES ({placeholders})", row)
        conn.commit()
        self.conn = conn
        return conn

    def run_generated_query(self, query: str) -> pd.DataFrame:
        if self.conn is None:
            raise Exception("Database connection is not initialized.")
        try:
            result_df = pd.read_sql_query(query, self.conn)
            print("QUERY EXECUTED SUCCESSFULLY")
            return result_df
        except Exception as e:
            print(f"FAILED TO RUN THE QUERY: {e}")
            return pd.DataFrame()

    def load_inputs(self, question: str) -> 'SQLQueryGenerator.GraphState':
        with open(os.path.join(self.files_folder, "schema.json"), "r") as f:
            schema = json.load(f)
        with open(os.path.join(self.files_folder, "data_dictionary.json"), "r") as f:
            data_dict = json.load(f)
        with open(os.path.join(self.files_folder, "domain_kb.txt"), "r") as f:
            domain_knowledge = f.read()
        return SQLQueryGenerator.GraphState(
            schema_data=schema,
            data_dict=data_dict,
            domain_knowledge=domain_knowledge,
            question=question,
            sql_query="",
            output_query=""
        )

    def generate_sql_node(self, state: 'SQLQueryGenerator.GraphState') -> 'SQLQueryGenerator.GraphState':
        prompt = f"""
You are a helpful assistant that generates SQL queries.

Given:
- Database Schema: {json.dumps(state['schema_data'], indent=2)}
- Data Dictionary: {json.dumps(state['data_dict'], indent=2)}
- Domain Knowledge: {state['domain_knowledge']}
- Question: {state['question']}

Generate a syntactically correct SQL query using the relevant column names and table names given to you.

Note: Give me only the SQL Query, I dont want any extra explanations of any kind.
"""
        response = self.llm.invoke(prompt)
        return {
            **state,
            "sql_query": response.content
        }

    def generate_output_query(self, state: 'SQLQueryGenerator.GraphState', result_df: pd.DataFrame) -> str:
        """
        Generates a chatbot-style, friendly natural language answer 
        to the user's question, using the DataFrame result from the SQL query.
        The prompt is optimized for speed and a conversational tone.
        Shows up to top 10 rows of the result for context.
        """
        if result_df.empty:
            return "Sorry, I couldn't find any data matching your question. Can I help with something else?"

        # Show up to top 10 rows for context and clarity
        df_str = result_df.head(10).to_markdown(index=False)
        col_list = ', '.join(result_df.columns)

        prompt = f"""
You are a helpful and friendly AI assistant in a chatbot.
Given the user's question, the SQL query used, and the following result table,
write a brief, conversational answer as you would in a chat.

- Question: {state['question']}
- SQL Query Used: {self.clean_sql_response(state['sql_query'])}
- Result Columns: {col_list}
- Top Results (up to 10 rows):
{df_str}

Reply conversationally, summarizing the main findings. If you cannot answer based on the table, say so.
"""

        response = self.llm.invoke(prompt)
        return response.content.strip()

    def build_graph(self):
        builder = StateGraph(SQLQueryGenerator.GraphState)
        builder.add_node("generate_sql", RunnableLambda(self.generate_sql_node))
        builder.set_entry_point("generate_sql")
        builder.set_finish_point("generate_sql")
        return builder.compile()

    def run(self):
        # Step 1: Load database
        self.load_csvs_into_memory()

        # Step 2: Prompt user for question
        user_question = input("Please enter your natural language question for the database:\n> ")

        # Step 3: Load input files with user question
        initial_state = self.load_inputs(user_question)

        # Step 4: Build and run graph
        app = self.build_graph()
        final_state = app.invoke(initial_state)

        print("*************************************")
        print("\n\nGenerated SQL Query:\n", final_state["sql_query"])
        print("*************************************")

        # Step 5: Clean SQL
        cleaned_sql_query = self.clean_sql_response(final_state["sql_query"])
        print("@@@@@@@@@@@@@@CLEANED SQL QUERY@@@@@@@@@@@@@@@@@")
        print(cleaned_sql_query)
        print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

        # Step 6: Run SQL
        result_df = self.run_generated_query(cleaned_sql_query)
        print(result_df)

        # Step 7: Generate natural language output query
        output_query = self.generate_output_query(final_state, result_df)
        print("###############################################")
        print("NATURAL LANGUAGE ANSWER TO USER QUESTION:")
        print(output_query)
        print("###############################################")

        return result_df, output_query

# ------- USAGE EXAMPLE -------

if __name__ == "__main__":
    generator = SQLQueryGenerator(csv_folder="./CSV_Files", files_folder="./Files")
    generator.run()
