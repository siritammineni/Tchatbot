from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi import Body
from pydantic import BaseModel
import os
import pandas as pd
import uuid

from data_dictionary_agent import DataDictionaryGenerator
from domain_agent import DomainKnowledgeProcessor
from schema_agent import CSVSchemaProcessor
from ambiguity_agent import AmbiguityAgent

# ---- NEW IMPORT ----
from text_to_sql import SQLQueryGenerator

# === NEW IMPORTS FOR GRAPH EXECUTION ===
from graph_classification_agent import GraphRequirementClassifier
from graph_selection_agent import GraphTypeSelector

app = FastAPI(debug=True)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)

# In-memory session store (for demonstration only; not for production use)
sessions = {}

# ---- Existing CSV upload endpoint ----
@app.post("/upload-csv/")
async def upload_csv(files: list[UploadFile] = File(...)):
    try:
        for file in files:
            file_location = os.path.join("CSV_Files", file.filename)
            # Save the uploaded file
            with open(file_location, "wb") as f:
                f.write(await file.read())

        # Process the CSV file using Data Dictionary agent
        ddg = DataDictionaryGenerator()
        ddg.run()

        # Process the CSV file using Domain agent
        processor = DomainKnowledgeProcessor(input_folder="CSV_Files", output_file="./Files/domain_kb.txt")
        processor.run()

        folder_path = "./CSV_Files"  # Update to your CSV folder path
        processor = CSVSchemaProcessor(folder_path)
        processor.process()
        return "Data Dictionary, Domain Knowledge and Schema has been created successfully."
    except Exception as ex:
        return "There was an Exception: " + str(ex)


# === Ambiguity Agent integration ===

class QueryInput(BaseModel):
    user_query: str
    session_id: str = None  # Optional for clarification flow

class ClarificationInput(BaseModel):
    clarification: str
    session_id: str

ambiguity_agent = AmbiguityAgent(schema_path="./Files/schema.json")
ambiguity_sessions = {}

@app.post("/check-ambiguity/")
async def check_ambiguity(input: QueryInput):
    # Run ambiguity check
    state = {
        "user_query": input.user_query,
        "schema": ambiguity_agent.schema_json_string,
        "clarification": None,
        "reframed_query": None,
        "ambiguous": None,
        "suggestions": None,
        "feedback": None,
    }
    result = ambiguity_agent.detect_ambiguity(state)

    # If ambiguous, store session for possible clarification
    if result.get("ambiguous"):
        session_id = input.session_id or str(uuid.uuid4())
        # Save context for this session
        ambiguity_sessions[session_id] = result
        return {
            "ambiguous": True,
            "clarification": result.get("clarification"),
            "suggestions": result.get("suggestions"),
            "feedback": result.get("feedback"),
            "session_id": session_id,
            "message": "Query is ambiguous. Please clarify and resubmit using /clarify-ambiguity endpoint."
        }
    else:
        # Not ambiguous: pass query ahead
        result = ambiguity_agent.pass_query(result)
        return {
            "ambiguous": False,
            "reframed_query": result.get("reframed_query"),
            "message": "Query is not ambiguous and can be processed."
        }

@app.post("/clarify-ambiguity/")
async def clarify_ambiguity(input: ClarificationInput):
    # Retrieve stored session state
    session = ambiguity_sessions.get(input.session_id)
    if not session:
        return JSONResponse(status_code=404, content={"error": "Session not found."})

    # Update the query with user's clarification
    session["user_query"] += f' [Clarified: {input.clarification}]'
    session["clarification"] = input.clarification

    # Reframe and pass the clarified query
    session = ambiguity_agent.reframe_query(session)
    # Remove session from memory after clarification
    ambiguity_sessions.pop(input.session_id, None)

    return {
        "ambiguous": False,
        "reframed_query": session.get("reframed_query"),
        "message": "Query clarified and reframed. Ready for processing."
    }

# ========== NEW ENDPOINT ==========
class TextToSQLInput(BaseModel):
    user_query: str

@app.post("/text-to-sql/")
async def text_to_sql(input: TextToSQLInput):
    try:
        generator = SQLQueryGenerator(csv_folder="./CSV_Files", files_folder="./Files")
        # This will load schema, data dict, domain kb, and use input.user_query
        generator.load_csvs_into_memory()
        initial_state = generator.load_inputs(input.user_query)
        app_graph = generator.build_graph()
        final_state = app_graph.invoke(initial_state)
        cleaned_sql_query = generator.clean_sql_response(final_state["sql_query"])
        result_df = generator.run_generated_query(cleaned_sql_query)
        # Convert DataFrame result to JSON
        result_json = result_df.to_dict(orient="records")
        
        # -- Generate chatbot-style, conversational output_query --
        # Only show up to top 10 rows for LLM context
        if result_df.empty:
            output_query = "Sorry, I couldn't find any data matching your question. Can I help with something else?"
        else:
            df_str = result_df.head(10).to_markdown(index=False)
            col_list = ', '.join(result_df.columns)
            prompt = f"""
You are a helpful and friendly AI assistant in a chatbot.
Given the user's question, the SQL query used, and the following result table,
write a brief, conversational answer as you would in a chat.

- Question: {input.user_query}
- SQL Query Used: {cleaned_sql_query}
- Result Columns: {col_list}
- Top Results (up to 10 rows):
{df_str}

Reply conversationally, summarizing the main findings. If you cannot answer based on the table, say so.
"""
            response = generator.llm.invoke(prompt)
            output_query = response.content.strip()
        
        return {
            "sql_query": cleaned_sql_query,
            "result": result_json,
            "output_query": output_query
        }
    except Exception as ex:
        return JSONResponse(status_code=500, content={"error": str(ex)})

# ========== END ==========

# ========== NEW GRAPH EXECUTION ENDPOINT ==========

class GraphExecutionInput(BaseModel):
    reframed_query: str

@app.post("/graph-execution/")
async def graph_execution(input: GraphExecutionInput):
    try:
        # 1. Run graph classification
        classifier = GraphRequirementClassifier()
        classification_result = classifier.run(input.reframed_query)

        if classification_result.get("graph_required", "").lower() == "graph":
            # 2. If graph required, run graph type selection
            selector = GraphTypeSelector()
            selection_result = selector.select_graph_type(input.reframed_query)
            return {
                "graph_required": "graph",
                "graph_type": selection_result.get("graph_type"),
                "graph_reasoning": selection_result.get("graph_reasoning")
            }
        else:
            # 3. If graph NOT required, return only that info
            return {
                "graph_required": "no graph",
                "message": "A graph/visualization is not required for this query."
            }
    except Exception as ex:
        return JSONResponse(status_code=500, content={"error": str(ex)})

# ========== END GRAPH EXECUTION ENDPOINT ==========

