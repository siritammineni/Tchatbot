import React from 'react'

function MainPage() {
  return (
    <div className='text-black'>
      ffffffffffffff
    </div>
  )
}

export default MainPage
