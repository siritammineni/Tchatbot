// import React, { useState, useEffect } from 'react';
// import "./DataConn.css";
// import { IoIosClose } from "react-icons/io";
// import { RiFileExcel2Fill } from "react-icons/ri";
// import CsvPreview from './CsvPreview'; // Adjust the path accordingly
// import Papa from 'papaparse';
// const DataConnection = () => {
//   // State for each button
//   const [csvActive, setCsvActive] = useState(true);
//   const [databaseActive, setDatabaseActive] = useState(false);
//   const [cloudActive, setCloudActive] = useState(false);
//   const [csvFiles, setCsvFiles] = useState([]); // Store multiple files
//   const [message, setMessage] = useState("");
//   const [errmessage, setErrMessage] = useState("");
//   const [isLoading, setIsLoading] = useState(false);
//   const [csvFile, setCsvFile] = useState(null);
//   const [csvData, setCsvData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [activeSource, setActiveSource] = useState('');
//   const [templateContent, setTemplateContent] = useState([]);
//   const [selectedSections, setSelectedSections] = useState([]);
//   // Function to toggle CSV File button state
//   const toggleCSV = () => {
//     setCsvActive(true);
//     setDatabaseActive(false);
//     setCloudActive(false);
//   };

//   // Function to toggle Database Connection button state
//   const toggleDatabase = () => {
//     setCsvActive(false);
//     setDatabaseActive(true);
//     setCloudActive(false);
//   };

//   // Function to toggle Cloud Storage button state
//   const toggleCloud = () => {
//     setCsvActive(false);
//     setDatabaseActive(false);
//     setCloudActive(true);
//   };
//   const handleFileChange = (event) => {
//     console.log("File input event:", event.target.files);
//     const files = Array.from(event.target.files); // Convert FileList to array
//     // Filter valid files
//     const validFiles = files.filter(
//       (file) =>
//         file.type === "text/csv" ||
//         file.type === "application/vnd.ms-excel" ||
//         file.type ===
//           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
//     );
//     // Map valid files to include metadata
//     const newFiles = validFiles.map((file) => ({
//       fileObject: file,
//       name: file.name,
//       type: file.type,
//       timestamp: Date.now(),
//     }));

//     // Append new files to the existing state
//     setCsvFiles((prev) => [...prev, ...newFiles]);
     
//     // Clear the file input to allow re-selection of the same file
//     event.target.value = null;
//   };
//   const handleCsvRemove = (fileObject) => {
//     console.log("removecsv", fileObject);
//     // Filter out the file to be removed
//     const updatedFiles = csvFiles.filter(
//       (file) => file.name !== fileObject.name
//     );
//     console.log("updatedcsvFIles", !updatedFiles);
//     // Update the state with the remaining files
//     setCsvFiles(updatedFiles);
//     setMessage("");
//     setErrMessage("");
//     console.log("updated files", updatedFiles.length);
//     if (updatedFiles.length === 0) {
//       console.log("empty");
//       setCsvFiles([]);
//     } else {
//       const firstFileURL = URL.createObjectURL(updatedFiles[0].fileObject);
//       console.log("firstfileurl", firstFileURL);
//      // setCsvFiles(firstFileURL);
//     }
//   };
//   const handleCsvClick = (fileObject) => {
//   if (!fileObject) return;

//   setLoading(true);
//   setCsvData([]); // Reset current data before parsing a new file

//   let rowCount = 0; // Initialize a counter to track the number of rows parsed

//   Papa.parse(fileObject, {
//     header: true,
//     skipEmptyLines: true,
//     worker: true, // Use a web worker for parsing
//     chunk: (results, parser) => {
//       const newRows = results.data;
//       const remainingRows = 20 - rowCount; // Calculate remaining rows needed to reach 20

//       if (remainingRows > 0) {
//         // Add only the remaining rows needed to reach 20
//         setCsvData((prevData) => [
//           ...prevData,
//           ...newRows.slice(0, remainingRows),
//         ]);
//         rowCount += newRows.length;

//         if (rowCount >= 20) {
//           parser.abort(); // Stop parsing once 20 rows have been processed
//         }
//       }
//     },
//     complete: () => {
//       setLoading(false);
//     },
//     error: (error) => {
//       console.error("Error parsing CSV file:", error);
//       setLoading(false);
//     },
//   });
// };

//    useEffect(() => {
//     console.log("Updated csvData:", csvData);
//   }, [csvFiles,csvData]); // This will run after pdfFiles state is updated
 
//  const handleUpload = async () => {
    
//     setIsLoading(true);
//     // Create a FormData object
//     const formData = new FormData();
   
//    csvFiles.forEach((file) => {
//       formData.append('files', file.fileObject); // 'files' is the key used in the backend
//     });
   
//     try {
//       const response = await fetch('http://127.0.0.1:8000/upload-csv', {
//         method: 'POST',
//         body: formData, // Send FormData directly
//       });
   
//       if (!response.ok) {
//         throw new Error(`Failed to upload files: ${response.statusText}`);
//       }
   
//       const data = await response.json();
//       setMessage(data);
      
//     } catch (error) {
//       console.error('Error creating index:', error);
//       setErrMessage(`Error creating index: ${error.message}`)
//     }finally {
//       setIsLoading(false);
//     }
//   };

// const handleTemplateUpload = (e) => {
//   const file = e.target.files[0];
//   if (!file) return;

//   const reader = new FileReader();

//   if (file.type === "application/pdf") {
//     reader.onload = function () {
//       const typedarray = new Uint8Array(reader.result);
//       import("pdfjs-dist/build/pdf").then(pdfjsLib => {
//         pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/2.10.377/pdf.worker.min.js`;

//         pdfjsLib.getDocument({ data: typedarray }).promise.then(pdf => {
//           let textPromises = [];
//           for (let i = 1; i <= pdf.numPages; i++) {
//             textPromises.push(pdf.getPage(i).then(page =>
//               page.getTextContent().then(content =>
//                 content.items.map(item => item.str).join(" ")
//               )
//             ));
//           }
//           Promise.all(textPromises).then(pages => {
//             const combined = pages.join("\n\n").split(/\n\s*\n/);
//             setTemplateContent(combined);
//           });
//         });
//       });
//     };
//     reader.readAsArrayBuffer(file);
//   } else {
//     reader.onload = () => {
//       const text = reader.result;
//       const split = text.split(/\n\s*\n/);
//       setTemplateContent(split);
//     };
//     reader.readAsText(file);
//   }
// };
// const toggleSelection = (section) => {
//   setSelectedSections((prev) =>
//     prev.includes(section)
//       ? prev.filter((s) => s !== section)
//       : [...prev, section]
//   );
// };

// const sendToChatbot = () => {
//   const query = selectedSections.join("\n\n");
//   localStorage.setItem("chatbot_prompt", query);
//   alert("Selected content sent to Chatbot!");
// };

//   return (
//     <div className="flex flex-col mt-10 ml-10 space-y-2">
//     <div className="flex space-x-12 mt-2">
//   <button
//   className={`flex items-center space-x-2 text-lg border px-4 py-2 rounded ${
//     activeSource === 'csv' ? "font-bold text-black bg-blue-500 border-blue-500" : "text-gray-700 bg-white border-gray-300"
//   }`}
//   onClick={() => setActiveSource('csv')}
// >
//   🗂️ <span>CSV File</span>
// </button>

// <button
//   className={`flex items-center space-x-2 text-lg border px-4 py-2 rounded ${
//     activeSource === 'database' ? "font-bold text-black bg-blue-500 border-blue-500" : "text-gray-700 bg-white border-gray-300"
//   }`}
//   onClick={() => setActiveSource('database')}
// >
//   💾 <span>Database Connection</span>
// </button>

// <button
//   className={`flex items-center space-x-2 text-lg border px-4 py-2 rounded ${
//     activeSource === 'cloud' ? "font-bold text-black bg-blue-500 border-blue-500" : "text-gray-700 bg-white border-gray-300"
//   }`}
//   onClick={() => setActiveSource('cloud')}
// >
//   ☁️ <span>Cloud Storage</span>
// </button>

// <button
//   className={`flex items-center space-x-2 text-lg border px-4 py-2 rounded ${
//     activeSource === 'template' ? "font-bold text-black bg-blue-500 border-blue-500" : "text-gray-700 bg-white border-gray-300"
//   }`}
//   onClick={() => setActiveSource('template')}
// >
//   📄 <span>Template Reader</span>
// </button>

// </div>

//       <div className="mt-6">
//         {activeSource === 'csv' && (
//           <>
//             <div className="upload-container mt-5 dark:bg-[#1e1e1e] bg-[#f7f7f7] border border-gray-300 dark:border-[#4f4f4f] border-dashed">
//               <input
//                 id="file-upload"
//                 type="file"
//                 multiple
//                 accept=".csv, .xls, .xlsx"
//                 onChange={handleFileChange}
//                 className="hidden-input"
//               />
//               <label
//                 htmlFor="file-upload"
//                 className="drag-label dark:text-[#D3D3D3]"
//               >
//                 Drag & drop file here, or click to browse
//               </label>
//             </div>
//             {csvFiles.length > 0 && (<>
//               <div className="flex">
//                 <div className="file-info dark:bg-[#1e1e1e] bg-[#f7f7f7]  border border-gray-300 dark:border-[#4f4f4f]">
//                   {csvFiles.length > 0 && (
//                     <div>
//                       <p className="text-left text-2xl font-bold dark:text-[#D3D3D3]">
//                         Documents
//                       </p>
//                       <div className="pdf-list mt-2 ml-2">
//                         {console.log("ramm",csvFiles)}
//                        {csvFiles.map((file, index) => (
//   <div key={index} className="flex  mb-2">
//     {/* Icon based on file type */}
//     <div className=" ">
//       {file.type && (
//         <RiFileExcel2Fill
//           style={{
//             color: "green",
//             marginTop: "4px",
         
//             width: "100%", // Use 100% width to fill the allocated space
//           }}
//         />
//       )}
//     </div>
    
//     {/* File Name */}
//     <p
//       className="ml-2 text-left truncate dark:text-[#d3d3d3] text-black"
//       style={{
//         cursor: "pointer",
//         overflow: "hidden",
//         whiteSpace: "nowrap",
//         textOverflow: "ellipsis",
//         width: '50%', // Set width to 20% as specified
//         margin:'0',
//         marginLeft:'0px'
//       }}
//     >
//       {file.name}
//     </p>
    
//     {/* Preview File Button */}
//     <button
//       className="ml-1 text-center text-white bg-blue-500 border border-blue-700 rounded "
//       style={{
//         cursor: "pointer",
//         width: '20%', // Set width to 20% for the button
//       }}
//        onClick={() => handleCsvClick(file.fileObject)}
//     >
//       Preview
//     </button>

//     {/* Remove File Button */}
//     <button
//       className="ml-1 text-left text-white bg-red-500 border border-red-700 rounded p-0.1 flex items-center justify-center"
//       style={{
//         cursor: "pointer",
//         width: '20%', // Set width to 20% for the button
//       }}
//       onClick={() => handleCsvRemove(file)}
//     >      
//       Remove
//     </button>
//   </div>
// ))}

//                           <div className="mt-5">
//                 {/* Button and Status */}
//                 <button
//                   className="home-button"
//                   onClick={handleUpload}
//                   disabled={isLoading}
//                 >
//                   {isLoading ? "Processing..." : "Upload"}
//                 </button>
//                 {isLoading && (
//                   <div className="progress-bar-container mt-3">
//                     <div className="progress-bar"></div>
//                   </div>
//                 )}
//                 {!isLoading && message && (
//                   <p className="message-box" style={{
//                                 overflow: "hidden", // Prevent overflowing text
//                                 whiteSpace: "nowrap", // Prevent wrapping to the next line
//                                 textOverflow: "ellipsis", // Add ellipsis for overflow
//                                 maxWidth: "98%", // Adjust the width as needed
//                               }} >{message}</p> // Display the success or error message
//                 )}
//                 {!isLoading && errmessage && (
//                   <p className="message-box1 text-red-400">{errmessage}</p> // Display the success or error message
//                 )}
//               </div>
//                       </div>
//                     </div>
//                   )}
//                 </div>
                
//           <div className="pdf-info ml-2 dark:bg-[#1e1e1e] bg-[#f7f7f7]  border border-gray-300 dark:border-[#4f4f4f]">
//        {loading && <p>Loading...</p>}
//       {csvData.length > 0 && (
//         <div style={{  padding: '10px' }}>
         
//           <table style={{ width: '100%', borderCollapse: 'collapse' }}>
//             <thead>
//               <tr>
//                 {Object.keys(csvData[0]).map((header, index) => (
//                   <th key={index} style={{ border: '1px solid #ddd', padding: '8px' }}>
//                     {header}
//                   </th>
//                 ))}
//               </tr>
//             </thead>
//             <tbody>
//               {csvData.map((row, rowIndex) => (
//                 <tr key={rowIndex}>
//                   {Object.values(row).map((value, cellIndex) => (
//                     <td key={cellIndex} style={{ border: '1px solid #ddd', padding: '8px' }}>
//                       {value}
//                     </td>
//                   ))}
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       )}
//    </div>
//                  </div>
//               </>
//             )}
//           </>
//         )}
//         {activeSource === 'database' && (
//           <div>Database Connection Content: Connect to your database here.</div>
//         )}
//         {activeSource === 'cloud' && (
//           <div>Cloud Storage Content: Manage your cloud storage services.</div>
//         )}
//         {activeSource === 'template' && (
//           <div className="template-sidebar p-4 border rounded bg-gray-50 dark:bg-[#1e1e1e] mt-4">
//             <h3 className="text-xl font-semibold mb-4 dark:text-white">Upload Template</h3>
//             <input
//               type="file"
//               accept=".doc,.docx,.pdf"
//               onChange={handleTemplateUpload}
//               className="mb-4"
//             />
//             <div className="template-preview space-y-3 max-h-[300px] overflow-y-auto">
//               {templateContent.map((section, idx) => (
//                 <div key={idx} className="template-section flex items-start gap-2">
//                   <input
//                     type="checkbox"
//                     checked={selectedSections.includes(section)}
//                     onChange={() => toggleSelection(section)}
//                   />
//                   <span className="dark:text-white text-gray-800">{section}</span>
//                 </div>
//               ))}
//             </div>
//             <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded" onClick={sendToChatbot}>
//               ➤ Send to Chatbot
//             </button>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };
// export default DataConnection;


import React, { useState, useEffect } from 'react';
import "./DataConn.css";
import { IoIosClose } from "react-icons/io";
import { RiFileExcel2Fill } from "react-icons/ri";
import Papa from 'papaparse';
import * as mammoth from "mammoth";
import * as pdfjsLib from "pdfjs-dist/build/pdf";
import axios from "axios"; 
import { useNavigate } from "react-router-dom"; 

const DataConnection = () => {
  const [csvActive, setCsvActive] = useState(true);
  const [databaseActive, setDatabaseActive] = useState(false);
  const [cloudActive, setCloudActive] = useState(false);
  const [csvFiles, setCsvFiles] = useState([]);
  const [message, setMessage] = useState("");
  const [errmessage, setErrMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [csvData, setCsvData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeSource, setActiveSource] = useState('csv');
 const [templateContent, setTemplateContent] = useState([]);
const [selectedSections, setSelectedSections] = useState([]);
const [uploadedTemplateFile, setUploadedTemplateFile] = useState(null);

const navigate = useNavigate();

useEffect(() => {
  const sendToChatbot = async () => {
    if (selectedSections.length === 0) return;

    const promptText = selectedSections.join("\n\n");

    try {
      const response = await axios.post("http://127.0.0.1:8000/chatbot", {
        prompt: promptText,
      });

      const chatbotReply = response.data.reply; // Assuming backend sends { reply: "..." }
      console.log("Chatbot Replied:", chatbotReply);

      // Optionally: store it in state, or localStorage, or redirect to chatbot page
      localStorage.setItem("chatbot_response", chatbotReply);
    } catch (error) {
      console.error("Error sending prompt to chatbot:", error);
    }
  };

  sendToChatbot();
}, [selectedSections]);

  const handleFileChange = (event) => {
    const files = Array.from(event.target.files);
    const validFiles = files.filter((file) =>
      ["text/csv", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"].includes(file.type)
    );
    const newFiles = validFiles.map((file) => ({
      fileObject: file,
      name: file.name,
      type: file.type,
      timestamp: Date.now(),
    }));
    setCsvFiles((prev) => [...prev, ...newFiles]);
    event.target.value = null;
  };

  const handleCsvRemove = (fileObject) => {
    const updatedFiles = csvFiles.filter((file) => file.name !== fileObject.name);
    setCsvFiles(updatedFiles);
    setMessage("");
    setErrMessage("");
  };

  const handleCsvClick = (fileObject) => {
    if (!fileObject) return;
    setLoading(true);
    setCsvData([]);
    let rowCount = 0;

    Papa.parse(fileObject, {
      header: true,
      skipEmptyLines: true,
      worker: true,
      chunk: (results, parser) => {
        const newRows = results.data;
        const remainingRows = 20 - rowCount;
        if (remainingRows > 0) {
          setCsvData((prevData) => [
            ...prevData,
            ...newRows.slice(0, remainingRows),
          ]);
          rowCount += newRows.length;
          if (rowCount >= 20) {
            parser.abort();
          }
        }
      },
      complete: () => {
        setLoading(false);
      },
      error: (error) => {
        console.error("Error parsing CSV file:", error);
        setLoading(false);
      },
    });
  };

  const handleUpload = async () => {
    setIsLoading(true);
    const formData = new FormData();
    csvFiles.forEach((file) => {
      formData.append('files', file.fileObject);
    });

    try {
      const response = await fetch('http://127.0.0.1:8000/upload-csv', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Failed to upload files: ${response.statusText}`);
      }

      const data = await response.json();
      setMessage(data);
    } catch (error) {
      console.error('Error creating index:', error);
      setErrMessage(`Error creating index: ${error.message}`)
    } finally {
      setIsLoading(false);
    }
  };

  const sendToChatbot = () => {
    const query = selectedSections.join("\n\n");
    localStorage.setItem("chatbot_prompt", query);
    alert("Selected content sent to Chatbot!");
  };

  const handleTemplateUpload = (event) => {
  const file = event.target.files[0];
  const reader = new FileReader();

  if (!file) return;

  setUploadedTemplateFile(file); // ← Store it in state
  const fileType = file.type;
  

  if (fileType === "application/pdf") {
    import('pdfjs-dist/build/pdf').then(pdfjsLib => {
      const pdfWorker = require('pdfjs-dist/build/pdf.worker.entry');
      pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

      const fileReader = new FileReader();
      fileReader.onload = function () {
        const typedArray = new Uint8Array(this.result);
        pdfjsLib.getDocument(typedArray).promise.then(pdf => {
          let textPromises = [];
          for (let i = 1; i <= pdf.numPages; i++) {
            textPromises.push(pdf.getPage(i).then(page => page.getTextContent()));
          }
          Promise.all(textPromises).then(pages => {
            const text = pages
              .flatMap(page => page.items.map(item => item.str))
              .filter(line => line.trim() !== "")
              .map(line => line.trim());
            setTemplateContent(text);
          });
        });
      };
      fileReader.readAsArrayBuffer(file);
    });
  } else if (
    fileType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  ) {
    import("mammoth").then(mammoth => {
      reader.onload = () => {
        mammoth.extractRawText({ arrayBuffer: reader.result }).then(result => {
          const lines = result.value.split("\n").filter(line => line.trim() !== "");
          setTemplateContent(lines);
        });
      };
      reader.readAsArrayBuffer(file);
    });
  } else if (
    fileType === "application/vnd.ms-excel" ||
    fileType === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  ) {
    Papa.parse(file, {
      complete: function (results) {
        const lines = results.data
          .flat()
          .filter(cell => typeof cell === "string" && cell.trim() !== "");
        setTemplateContent(lines);
      }
    });
  } else {
    alert("Unsupported file type. Please upload PDF, Word, or Excel.");
  }
};

const toggleSelection = (section) => {
  // Store only the clicked checkbox section in localStorage
  localStorage.setItem("chatbot_prompt", section);

  const updatedSections = selectedSections.includes(section)
    ? selectedSections.filter((s) => s !== section)
    : [...selectedSections, section];

  setSelectedSections(updatedSections);

  // Navigate to chatbot playground with query param or just go
  navigate("/chatbot");
};

const clearTemplateUpload = () => {
  setUploadedTemplateFile(null);
  setTemplateContent([]);
  setSelectedSections([]);
};


  return (
    <div className="flex flex-col mt-10 ml-10 space-y-2">
      <div className="flex space-x-12 mt-2">
        <button
          className={`flex items-center space-x-2 text-lg border px-4 py-2 rounded ${activeSource === 'csv' ? "font-bold text-black bg-blue-500 border-blue-500" : "text-gray-700 bg-white border-gray-300"}`}
          onClick={() => setActiveSource('csv')}
        >
          🗂️ <span>Data files</span>
        </button>

        <button
          className={`flex items-center space-x-2 text-lg border px-4 py-2 rounded ${activeSource === 'database' ? "font-bold text-black bg-blue-500 border-blue-500" : "text-gray-700 bg-white border-gray-300"}`}
          onClick={() => setActiveSource('database')}
        >
          💾 <span>Database Connection</span>
        </button>

        <button
          className={`flex items-center space-x-2 text-lg border px-4 py-2 rounded ${activeSource === 'cloud' ? "font-bold text-black bg-blue-500 border-blue-500" : "text-gray-700 bg-white border-gray-300"}`}
          onClick={() => setActiveSource('cloud')}
        >
          ☁️ <span>Cloud Storage</span>
        </button>

        <button
          className={`flex items-center space-x-2 text-lg border px-4 py-2 rounded ${activeSource === 'template' ? "font-bold text-black bg-blue-500 border-blue-500" : "text-gray-700 bg-white border-gray-300"}`}
          onClick={() => setActiveSource('template')}
        >
          📄 <span>Template Reader</span>
        </button>
      </div>

      <div className="mt-6">
        {activeSource === 'csv' && (
          <>
            <div className="upload-container mt-5 dark:bg-[#1e1e1e] bg-[#f7f7f7] border border-gray-300 dark:border-[#4f4f4f] border-dashed">
              <input
                id="file-upload"
                type="file"
                multiple
                accept=".csv, .xls, .xlsx"
                onChange={handleFileChange}
                className="hidden-input"
              />
              <label htmlFor="file-upload" className="drag-label dark:text-[#D3D3D3]">
                Drag & drop file here, or click to browse
              </label>
            </div>

            {csvFiles.length > 0 && (
              <div className="flex">
                <div className="file-info dark:bg-[#1e1e1e] bg-[#f7f7f7] border border-gray-300 dark:border-[#4f4f4f]">
                  <p className="text-left text-2xl font-bold dark:text-[#D3D3D3]">Documents</p>
                  <div className="pdf-list mt-2 ml-2">
                    {csvFiles.map((file, index) => (
                      <div key={index} className="flex mb-2">
                        <div>
                          <RiFileExcel2Fill style={{ color: "green", marginTop: "4px", width: "100%" }} />
                        </div>
                        <p className="ml-2 text-left truncate dark:text-[#d3d3d3] text-black" style={{ width: '50%' }}>
                          {file.name}
                        </p>
                        <button
                          className="ml-1 text-center text-white bg-blue-500 border border-blue-700 rounded"
                          style={{ width: '20%' }}
                          onClick={() => handleCsvClick(file.fileObject)}
                        >
                          Preview
                        </button>
                        <button
                          className="ml-1 text-white bg-red-500 border border-red-700 rounded"
                          style={{ width: '20%' }}
                          onClick={() => handleCsvRemove(file)}
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                    <div className="mt-5">
                      <button className="home-button" onClick={handleUpload} disabled={isLoading}>
                        {isLoading ? "Processing..." : "Upload"}
                      </button>
                      {isLoading && <div className="progress-bar-container mt-3"><div className="progress-bar"></div></div>}
                      {!isLoading && message && (
                        <p className="message-box" style={{ whiteSpace: "nowrap", textOverflow: "ellipsis", maxWidth: "98%" }}>{message}</p>
                      )}
                      {!isLoading && errmessage && (
                        <p className="message-box1 text-red-400">{errmessage}</p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="pdf-info ml-2 dark:bg-[#1e1e1e] bg-[#f7f7f7] border border-gray-300 dark:border-[#4f4f4f]">
                  {loading && <p>Loading...</p>}
                  {csvData.length > 0 && (
                    <div style={{ padding: '10px' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                        <thead>
                          <tr>
                            {Object.keys(csvData[0]).map((header, index) => (
                              <th key={index} style={{ border: '1px solid #ddd', padding: '8px' }}>{header}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {csvData.map((row, rowIndex) => (
                            <tr key={rowIndex}>
                              {Object.values(row).map((value, cellIndex) => (
                                <td key={cellIndex} style={{ border: '1px solid #ddd', padding: '8px' }}>{value}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            )}
          </>
        )}

        {activeSource === 'database' && (
          <div>Database Connection Content: Connect to your database here.</div>
        )}
        {activeSource === 'cloud' && (
          <div>Cloud Storage Content: Manage your cloud storage services.</div>
        )}
        {activeSource === 'template' && (
          <div className="mt-6 dark:bg-[#1e1e1e] bg-[#f7f7f7] p-4 border border-gray-300 dark:border-[#4f4f4f] rounded">
            <h2 className="text-xl font-semibold dark:text-white text-black">Upload Template</h2>
            <input
              type="file"
              accept=".pdf,.doc,.docx,.xls,.xlsx"
              onChange={handleTemplateUpload}
              className="mt-2 mb-4"
            />
             {uploadedTemplateFile && (
              <button
                className="text-red-500 border border-red-500 px-3 py-1 rounded hover:bg-red-100 mt-2 mb-4"
                onClick={clearTemplateUpload}
              >
                ✖️Clear
              </button>
            )}

            {templateContent.length > 0 && (
              <div className="space-y-2">
                <h3 className="text-lg font-medium dark:text-white text-black">Select Sections to Send to Chatbot</h3>
                {templateContent.map((line, idx) => (
                  <div key={idx} className="flex items-start space-x-2">
                    <input
                      type="checkbox"
                      checked={selectedSections.includes(line)}
                      onChange={() => toggleSelection(line)}
                    />
                    <span className="text-gray-800 dark:text-gray-300">{line}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default DataConnection;
