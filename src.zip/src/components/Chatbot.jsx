import React, { useState, useRef, useEffect } from 'react';
import { FiSend } from "react-icons/fi";
import "./Chatbot.css";
import { ThumbsUp, ThumbsDown, Copy, Download } from "lucide-react";
import { data } from "react-router-dom";
import BarChart from "./BarChart"; 
import PieChart from "./PieChart"; 
import axios from 'axios';

const dummyChartData = {
  labels: ["January", "February", "March", "April", "May"],
  label: "Monthly Sales",
  values: [65, 59, 80, 81, 56],
};
const Chatbot = () => {
  const [messages, setMessages] = useState({AIARENA: [] });
  const [inputValue, setInputValue] = useState("");
  const [showHistory, setShowHistory] = useState(false);
  const [chatList, setChatList] = useState(["AIARENA"]);
  const [isTyping, setIsTyping] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState(null);
  const [likedIndex, setLikedIndex] = useState(null);
  const [responseTime, setResponseTime] = useState(null);
  const [ambiguous, setAmbiguous] = useState(true);
  const [suggestion, setSuggestion] = useState(false);
  const [currentChat, setCurrentChat] = useState("AIARENA");
  const [graphType, setGraphType] = useState("PieChart");
  const [response, setResponse] = useState("");
  const [showUploadOptions, setShowUploadOptions] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [agentSteps, setAgentSteps] = useState([]);         
  const [completedSteps, setCompletedSteps] = useState([]); 
  const [showAgentFlow, setShowAgentFlow] = useState(false); 
  const [showDbModal, setShowDbModal] = useState(false);
  const [dbConfig, setDbConfig] = useState({ host: '', user: '', password: '' });
  const [prompt, setPrompt] = useState('');
  
  const popupRef = useRef(null);
  const fileInputRef = useRef(null);

  const fileFlow = [
  "File Uploaded",
  "Schema Agent",
  "Domain Agent",
  "DD Agent"
  ];

  const queryFlow = [
    "Query Sent",
    "Schema Agent",
    "Ambiguity Agent"
  ];

const toggleUploadOptions = () => {
  setShowUploadOptions(!showUploadOptions);
};

// const handleFileUpload = () => {
//   if (fileInputRef.current) {
//     fileInputRef.current.click();
//   }
//   // Show sidebar and set agent steps
//   setAgentSteps(fileFlow);
//   setCompletedSteps(["File Uploaded"]);
//   setShowAgentFlow(true);
// };
const handleFileUpload = () => {
  if (fileInputRef.current) {
    fileInputRef.current.click(); // Trigger file input
  }

  const listener = (e) => {
    const file = e.target.files[0];
    if (file) {
      const promptText = `User uploaded file: ${file.name}`;
      setPrompt(promptText); // Set prompt in text area

      // Cleanup listener
      fileInputRef.current.removeEventListener("change", listener);

      // 👉 Immediately send to chatbot UI
      sendPromptToBackend(promptText);

      // 👉 Open sidebar AFTER chatbot receives prompt
      setTimeout(() => {
        // Set up agent steps
        setAgentSteps([
          "File Uploaded",
          "Schema Agent",
          "Domain Agent",
          "DD Agent",
          "Response Generated",
        ]);

        // ✅ Step 1: File Uploaded
        setCompletedSteps(["File Uploaded"]);
        setShowAgentFlow(true);

        // ⏳ Step 2: Schema Agent (delay)
        setTimeout(() => {
          setCompletedSteps((prev) => [...prev, "Schema Agent"]);
        }, 1500);

        // ⏳ Step 3: Domain Agent
        setTimeout(() => {
          setCompletedSteps((prev) => [...prev, "Domain Agent"]);
        }, 3000);

        // ⏳ Step 4: DD Agent
        setTimeout(() => {
          setCompletedSteps((prev) => [...prev, "DD Agent"]);
        }, 4500);

        // ✅ Step 5: Response Generated (final)
        setTimeout(() => {
          setCompletedSteps((prev) => [...prev, "Response Generated"]);
        }, 6500);
      }, 600); // Delay slightly to ensure chatbot response appears first
    }
  };

  fileInputRef.current.addEventListener("change", listener);
};




const connectToDB = () => {
  setShowDbModal(true);

  setAgentSteps(fileFlow);
  setCompletedSteps(["File Uploaded"]);
  setShowAgentFlow(true);
};

const connectToRealDB = async () => {
  try {
    // Simulate or call backend API to connect DB here
    setInputValue((prev) => `${prev}\nConnected to DB: ${dbConfig.host}`);
    setShowDbModal(false);
  } catch (err) {
    console.error("DB Connect failed", err);
  }
};

const connectToCloud = () => {
  setInputValue((prev) => `${prev}\nConnected to Google Drive account.`);

  setAgentSteps(fileFlow);
  setCompletedSteps(["File Uploaded"]);
  setShowAgentFlow(true);
};

const handleFileChange = (e) => {
  const files = e.target.files;
  if (files.length > 0) {
    const file = files[0];
    const promptText = `User uploaded file: ${file.name}`;
    setInputValue((prev) => `${prev}\n${promptText}`);
  }
};
  // Close popup on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (popupRef.current && !popupRef.current.contains(event.target)) {
        setShowUploadOptions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
  if (agentSteps.length > 0 && completedSteps.length < agentSteps.length) {
    const timer = setTimeout(() => {
      const nextStep = agentSteps[completedSteps.length];
      setCompletedSteps(prev => [...prev, nextStep]);
    }, 1500); // 1.5s delay per step

    return () => clearTimeout(timer);
  }
}, [completedSteps, agentSteps]);

  useEffect(() => {
    const res = localStorage.getItem("chatbot_response");
    if (res) setResponse(res);
  }, []);

  const addNewChat = () => {
    const nextChatNumber = chatList.length + 1;
    const newChatId = `Chat${
      nextChatNumber < 10 ? "0" + nextChatNumber : nextChatNumber
    }`;
    setChatList([...chatList, newChatId]);
    setCurrentChat(newChatId);
    setMessages((prevMessages) => ({ ...prevMessages, [newChatId]: [] })); // Initialize empty message array for new chat
  };
  const toggleHistory = () => {
    setShowHistory((prevState) => !prevState);
  };
  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  useEffect(() => {
    const storedPrompt = localStorage.getItem("chatbot_prompt");
    if (storedPrompt) {
      setPrompt(storedPrompt);
      sendPromptToBackend(storedPrompt);
      localStorage.removeItem("chatbot_prompt"); // Optional: Clear after use
    }
  }, []);

  const sendPromptToBackend = async (query) => {
    // Add user prompt to chat messages
  const userMessage = { role: "user", content: query };
  setMessages((prev) => ({
    ...prev,
    [currentChat]: [...prev[currentChat], userMessage],
  }));
  setIsTyping(true); // Show typing animation
    try {
      const res = await axios.post("http://127.0.0.1:8000/chatbot", {
        prompt: query,
      });

      const botMessage = { role: "assistant", content: res.data.reply };
      setMessages((prev) => ({
        ...prev,
        [currentChat]: [...prev[currentChat], userMessage, botMessage],
      }));
    } catch (error) {
      console.error("Error fetching chatbot response:", error);
      const errorMessage = { role: "assistant", content: "Error fetching response from backend." };
      setMessages((prev) => ({
        ...prev,
        [currentChat]: [...prev[currentChat], userMessage, errorMessage],
      }));
    } finally {
      setIsTyping(false);
      setPrompt(""); 
    }
  };

  function handleSuggestionClick(suggestion) {
    // Handle the suggestion click event
    console.log("Suggestion clicked:", suggestion);
    setInputValue(suggestion);
    setSuggestion(true);
    // Implement any logic needed when a suggestion is clicked
  }
  const generateChartData = (data) => {
    const colors = [
      "rgba(75, 192, 192, 0.2)",
      "rgba(255, 99, 132, 0.2)",
      "rgba(54, 162, 235, 0.2)",
      "rgba(255, 206, 86, 0.2)",
      "rgba(153, 102, 255, 0.2)",
      "rgba(255, 159, 64, 0.2)",
      "rgba(201, 203, 207, 0.2)",
      "rgba(64, 159, 64, 0.2)",
      "rgba(159, 64, 255, 0.2)",
      "rgba(64, 159, 255, 0.2)",
    ];

    const borderColor = colors.map((color) => color.replace("0.2", "1"));
    // Get the keys from the first item dynamically
    const firstItemKeys = Object.keys(data[0]);
    const labelKey = firstItemKeys[0]; // Assuming the first key is for labels
    const dataKey = firstItemKeys[1]; // Assuming the second key is for data
    return {
      labels: data.map((item) => item[labelKey]),
      datasets: [
        {
          label: `Data by ${labelKey}`,
          data: data.map((item) => item[dataKey]),
          backgroundColor: colors.slice(0, data.length), // Adjust to number of items
          borderColor: borderColor.slice(0, data.length), // Adjust to number of items
          borderWidth: 1,
        },
      ],
    };
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() && !suggestion) return;
    // Start the agent sidebar flow
  const queryFlow = ["Query Received", "Schema Agent", "Ambiguity Agent"];
  setAgentSteps(queryFlow);
  setCompletedSteps(["Query Received"]);
  setShowAgentFlow(true);
    if (!messages[currentChat]) {
      setMessages((prevMessages) => ({ ...prevMessages, [currentChat]: [] }));
    }
    // Add user message to current chat
    setMessages((prevMessages) => ({
      ...prevMessages,
      [currentChat]: [
        ...prevMessages[currentChat],
        { role: "user", content: inputValue },
      ],
    }));
    setInputValue("");
    setIsTyping(true);

    try {
      const res = await fetch("http://127.0.0.1:8000/check-ambiguity", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_query: inputValue.trim(),
          session_id: "string", // Replace with the actual session_id if available
        }),
      });
      if (res.ok) {
        console.log(messages);
        const data = await res.json();
        console.log("ffffffffffff", data);
        const endTime = performance.now();
        const timeTaken = data.response_time; //((endTime - startTime) / 1000).toFixed(2);
        setAmbiguous(data.ambiguous);
        setResponseTime(timeTaken);
        // Simulate progressive agent completion
        setTimeout(() => {
          setCompletedSteps(["Query Received", "Schema Agent"]);
        }, 600);
        setTimeout(() => {
          setCompletedSteps(["Query Received", "Schema Agent", "Ambiguity Agent"]);
        }, 1200);

        if (data.ambiguous === false) {
          handleSendMessage3();
        } else {
          const assistantMsg = {
            role: "assistant",
            content: data.clarification,
            suggestion: data.suggestions, // Combine suggestions into a single string
          };
          setMessages((prevMessages) => ({
            ...prevMessages,
            [currentChat]: [...prevMessages[currentChat], assistantMsg],
          }));
        }
      }
    } catch (error) {
      console.error("Generation error:", error);
      const assistantMsg = {
        role: "assistant",
        content: "something went wrong",
      };

      setMessages((prevMessages) => ({
        ...prevMessages,
        [currentChat]: [...prevMessages[currentChat], assistantMsg],
      }));
    } finally {
      setIsTyping(false);
      //setLoading(false);
    }
  };
  const handleSendMessage1 = async () => {
    if (!inputValue.trim() && !suggestion) return;

    if (!messages[currentChat]) {
      setMessages((prevMessages) => ({ ...prevMessages, [currentChat]: [] }));
    }
    setMessages((prevMessages) => ({
      ...prevMessages,
      [currentChat]: [
        ...prevMessages[currentChat],
        { role: "user", content: inputValue },
      ],
    }));
    setInputValue("");
    setIsTyping(true); // Start typing indicator

    try {
      const res = await fetch("http://127.0.0.1:8000/clarify-ambiguity", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          clarification: inputValue.trim(),
          session_id: "string", // Replace with the actual session_id if available
        }),
      });
      if (res.ok) {
        const data = await res.json();
        console.log("ffffffffffff", data);
        const timeTaken = data.response_time;

        setResponseTime(timeTaken);
        setAmbiguous(data.ambiguous);
        if (data.ambiguous === false) {
          setSuggestion(false);
          handleSendMessage3(); // Call the second API and wait for its completion
        }
      }
    } catch (error) {
      console.error("Generation error:", error);

      const assistantMsg = {
        role: "assistant",
        content: "something went wrong",
      };
      setMessages((prevMessages) => ({
        ...prevMessages,
        [currentChat]: [...prevMessages[currentChat], assistantMsg],
      }));
    }
  };

  const handleSendMessage2 = async (type) => {
    if (!inputValue.trim() && !suggestion) return;
    
    if (!messages[currentChat]) {
      setMessages((prevMessages) => ({ ...prevMessages, [currentChat]: [] }));
    }
    setInputValue("");
    setIsTyping(true);
    try {
      const res = await fetch("http://127.0.0.1:8000/text-to-sql", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_query: inputValue.trim(),
          session_id: "string", // Replace with the actual session_id if available
        }),
      });
      if (res.ok) {
        const data = await res.json();
        console.log("ffffffffffff", data);
        const timeTaken = data.response_time;

        setResponseTime(timeTaken);
        setAmbiguous(true);
        const assistantMsg = {
          role: "assistant",
          content: data.output_query,
          chartData: generateChartData(data.result),
           graphType1: type === 'PieChart' ? 'PieChart' : 'BarChart', // Conditional adjustmen
          suggestion: data.suggestions,
        };

        setMessages((prevMessages) => ({
          ...prevMessages,
          [currentChat]: [...prevMessages[currentChat], assistantMsg],
        }));
      }
    } catch (error) {
      console.error("Generation error:", error);
      const assistantMsg = {
        role: "assistant",
        content: "something went wrong",
      };
      setMessages((prevMessages) => ({
        ...prevMessages,
        [currentChat]: [...prevMessages[currentChat], assistantMsg],
      }));
    } finally {
      setIsTyping(false);
      //setLoading(false);
    }
  };

  const handleSendMessage3 = async () => {
    if (!inputValue.trim() && !suggestion) return;
    if (!messages[currentChat]) {
      setMessages((prevMessages) => ({ ...prevMessages, [currentChat]: [] }));
    }
    // Add user message to current chat
    setInputValue("");
    setIsTyping(true);
    try {
      const res = await fetch("http://127.0.0.1:8000/graph-execution", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          reframed_query: inputValue.trim(),
        }),
      });
      if (res.ok) {
        console.log(messages);

        const data = await res.json();
        console.log("ffffffffffff", data);
        const endTime = performance.now();
        const timeTaken = data.response_time; //((endTime - startTime) / 1000).toFixed(2);
        setResponseTime(timeTaken);
        if (data.graph_required === "graph") {
          const normalizedGraphType = data.graph_type.toLowerCase();
          if (normalizedGraphType.includes("pie")) {
                      handleSendMessage2('PieChart');
          } else if (normalizedGraphType.includes("bar")) {
                      handleSendMessage2('BarChart');
          }
        } else {
          const assistantMsg = {
            role: "assistant",
            content: data.clarification,
            suggestion: data.suggestions, // Combine suggestions into a single string
          };
          setMessages((prevMessages) => ({
            ...prevMessages,
            [currentChat]: [...prevMessages[currentChat], assistantMsg],
          }));
        }
      }
    } catch (error) {
      console.error("Generation error:", error);
      const assistantMsg = {
        role: "assistant",
        content: "something went wrong",
      };

      setMessages((prevMessages) => ({
        ...prevMessages,
        [currentChat]: [...prevMessages[currentChat], assistantMsg],
      }));
    } finally {
      setIsTyping(true);
      //setLoading(false);
    }
  };
  useEffect(() => {}, [showHistory, currentChat, inputValue,graphType]);

  return (
  <div className="flex w-full h-full">
    {/* LEFT: Main Chat UI (70% or 100%) */}
    <div className={`${showAgentFlow ? "w-[70%]" : "w-full"} transition-all duration-500`}>
      <div className="h-screen bg-white flex">
        <div
          className={`page-container transition-all duration-300 ${
            showHistory ? "" : "w-full"
          }`}
          style={{ width: showHistory ? "70%" : "100%" }}
        >
          <div className="content-header">
            <p className="text-3xl">{currentChat} </p>
            <div
              className="button-group1"
              style={{
                display: "flex",
                gap: "10px",
                position: "absolute",
                right: "0",
              }}
            >
              <button className="history-button text-xl" onClick={toggleHistory}>
                ChatHistory
              </button>
              <button className="new-chat-button text-xl" onClick={addNewChat}>
                Start New
              </button>
            </div>
          </div>

          {messages[currentChat].length !== 0 && (
            <div className="chat-container p-4">
              {(messages[currentChat] || []).map((msg, i) => (
                <div
                  key={i}
                  className={`flex flex-col ${
                    msg.role === "user" ? "items-end" : "items-start mt-2"
                  }`}
                >
                  <div
                    className={`items-center justify-center p-2 rounded flex-shrink border w-fit max-w-[65%] min-w-[48px] min-h-[65px] break-words whitespace-normal ${
                      msg.role === "user"
                        ? "bg-[#EDF5FD] text-black border-gray-200"
                        : "bg-white text-black border-gray-200"
                    }`}
                  >
                    {msg.role === "assistant" ? ` ${msg.content}` : ` ${msg.content}`}
                    {msg.role === "assistant" && msg.chartData ? (
                      <>
                        {msg.graphType1 === "BarChart" && <BarChart chartData={msg.chartData} />}
                        {msg.graphType1 === "PieChart" && <PieChart chartData={msg.chartData} />}
                      </>
                    ) : (
                      <span></span>
                    )}
                    {msg.suggestion &&
                      msg.suggestion.map((suggestion, index) => (
                        <div key={index} className="mt-2 items-left">
                          <button
                            onClick={() => handleSuggestionClick(suggestion)}
                            className="mt-1 text-blue-700 text-sm hover:underline"
                          >
                            {suggestion}
                          </button>
                        </div>
                      ))}
                  </div>

                  {msg.role === "assistant" && (
                    <div className="flex gap-2 mt-1 text-blue-700">
                      <ThumbsUp
                        className={`w-4 h-4 cursor-pointer transition ${
                          likedIndex === `up-${i}` ? "fill-blue-600" : "hover:text-blue-600"
                        }`}
                        onClick={() => setLikedIndex(`up-${i}`)}
                      />
                      <ThumbsDown
                        className={`w-4 h-4 cursor-pointer transition ${
                          likedIndex === `down-${i}` ? "fill-blue-600" : "hover:text-blue-600"
                        }`}
                        onClick={() => setLikedIndex(`down-${i}`)}
                      />
                      <Copy
                        className={`w-4 h-4 cursor-pointer transition ${
                          copiedIndex === i ? "text-green-600 scale-110" : "hover:text-blue-600"
                        }`}
                        onClick={() => handleCopy(msg.content, i)}
                      />
                      {copiedIndex === i && (
                        <span className="text-xs text-green-600 font-medium">Copied!</span>
                      )}
                    </div>
                  )}
                </div>
              ))}

              {isTyping && (
                <div className="flex flex-col items-start">
                  <div className="items-center justify-center p-2 rounded bg-white text-black border border-gray-200 animate-pulse">
                    <div className="flex items-center gap-2">
                      <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                      <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                      <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce"></span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="input-container ">
            <div className="input-container relative p-2 border-t dark:border-[#4f4f4f] flex items-center">
              {/* + Icon (inside textarea area) */}
              <div className="absolute left-4 bottom-3">
                <button
                  className="text-black dark:text-white bg-transparent"
                  onClick={toggleUploadOptions}
                >
                  <span className="text-5xl font">+</span>
                </button>

                {showUploadOptions && (
                  <div
                    ref={popupRef}
                    className="absolute bottom-10 left-0 bg-white border rounded-md shadow-lg z-14 w-56"
                  >
                    <ul className="text-sm text-left">
                      <li
                        className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                        onClick={handleFileUpload}
                      >
                        📁 Add Photos and Files
                      </li>
                      <li
                        className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                        onClick={connectToDB}
                      >
                        🗄️ Connect to DB
                      </li>
                      <li
                        className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                        onClick={connectToCloud}
                      >
                        ☁️ Connect to Cloud
                      </li>
                    </ul>
                  </div>
                )}
              </div>

              <textarea
                className="flex-grow h-29 dark:bg-[#1e1e1e] bg-white border border-gray-300 dark:border-[#4f4f4f] dark:text-white text-black p-6 pl-18 rounded"
                placeholder="Type your question here..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              ></textarea>

              {/* Send Button */}
              {ambiguous && !suggestion && (
                // <button className="send-button ml-2" onClick={handleSendMessage}>
                <button className="send-button ml-2" 
                        onClick={() => sendPromptToBackend(prompt)}>
                  <FiSend className="send-icon" />
                </button>
              )}
              {ambiguous && suggestion && (
                // <button className="send-button ml-2" onClick={handleSendMessage1}>
                <button className="send-button ml-2" 
                        onClick={() => sendPromptToBackend(prompt)}>
                  <FiSend className="send-icon" />
                </button>
              )}

              {response && (
                <div className="mt-4 px-4">
                  <h4 className="text-lg font-semibold">Response:</h4>
                  <p className="text-gray-800">{response}</p>
                </div>
              )}

              {/* Hidden File Input */}
              <input
                type="file"
                ref={fileInputRef}
                style={{ display: "none" }}
                multiple
                onChange={handleFileChange}
              />
            </div>
          </div>
        </div>

        {showHistory && (
          <div className="history-box ml-2 mt-2 transition-all duration-300 text-left m-0 relative">
            {/* Close (X) Icon */}
            <button
              className="absolute top-2 right-2 text-gray-500 hover:text-red-600 text-5xl font"
              onClick={() => setShowHistory(false)}
              title="Close Chat History"
            >
              &times;
            </button>

            <h2 className="history-title mt-6">ChatHistory</h2>
            <ul className="chat-list">
              {chatList.map((chat, index) => (
                <li
                  key={index}
                  className={`chat-item ${currentChat === chat ? "active" : ""}`}
                  onClick={() => setCurrentChat(chat)}
                >
                  {chat}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>

    {/* RIGHT: Agent Flow Sidebar */}
    {showAgentFlow && (
      <div className="w-[30%] bg-[#1e1e1e] text-white p-4 shadow-md border-l border-gray-700">
        <h2 className="text-lg font-semibold mb-4">Agent Progress</h2>
        <ul className="space-y-4">
          {agentSteps.map((step, index) => (
            <li
              key={index}
              className={`flex justify-between items-center px-4 py-2 rounded-md 
                ${completedSteps.includes(step) ? "bg-green-700" : "bg-gray-800"}`}
            >
              <span>{step}</span>
              <span className="text-sm">
                {completedSteps.includes(step) ? "Completed" : "Pending"}
              </span>
            </li>
          ))}
        </ul>
      </div>
    )}

    {showDbModal && (
      <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-30 z-50">
        <div className="bg-white p-6 rounded shadow-lg w-80">
          <h2 className="text-xl font-bold mb-4">Connect to Database</h2>
          <input
            className="w-full border p-2 mb-2"
            placeholder="Host"
            value={dbConfig.host}
            onChange={(e) => setDbConfig({ ...dbConfig, host: e.target.value })}
          />
          <input
            className="w-full border p-2 mb-2"
            placeholder="User"
            value={dbConfig.user}
            onChange={(e) => setDbConfig({ ...dbConfig, user: e.target.value })}
          />
          <input
            className="w-full border p-2 mb-4"
            placeholder="Password"
            type="password"
            value={dbConfig.password}
            onChange={(e) => setDbConfig({ ...dbConfig, password: e.target.value })}
          />
          <div className="flex justify-between">
            <button className="bg-blue-500 text-white px-4 py-1 rounded" onClick={connectToRealDB}>
              Connect
            </button>
            <button className="text-gray-600" onClick={() => setShowDbModal(false)}>
              Cancel
            </button>
          </div>
        </div>
      </div>
    )}
  </div>
);
};
export default Chatbot;
